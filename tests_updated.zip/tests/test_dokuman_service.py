"""
DokumanService Test Suite

Kapsam:
- Başlatma doğrulaması
- upload_and_save: offline (local) mod
- get_dokumanlar: entity filtresi
- sil
"""
import pytest
from unittest.mock import MagicMock, patch
from core.services.dokuman_service import DokumanService


# ─────────────────────────────────────────────────────────────
#  Fixture'lar
# ─────────────────────────────────────────────────────────────

@pytest.fixture
def reg():
    return MagicMock()


@pytest.fixture
def db():
    return MagicMock()


@pytest.fixture
def svc(db, reg):
    return DokumanService(db, reg)


# ─────────────────────────────────────────────────────────────
#  Başlatma
# ─────────────────────────────────────────────────────────────

class TestInit:
    def test_none_db_hata_firlatar(self, reg):
        with pytest.raises((ValueError, TypeError)):
            DokumanService(None, reg)

    def test_registry_saklanir(self, db, reg):
        s = DokumanService(db, reg)
        assert s._r is reg


# ─────────────────────────────────────────────────────────────
#  get_dokumanlar
# ─────────────────────────────────────────────────────────────

class TestGetDokumanlar:
    def _veri(self):
        return [
            {"EntityType": "personel", "EntityId": "111", "BelgeTuru": "Diploma",   "Belge": "d1.pdf"},
            {"EntityType": "personel", "EntityId": "111", "BelgeTuru": "Sertifika", "Belge": "s1.pdf"},
            {"EntityType": "cihaz",    "EntityId": "C01", "BelgeTuru": "Lisans",    "Belge": "l1.pdf"},
        ]

    def test_entity_filtresi(self, svc, reg):
        reg.get("Dokumanlar").get_all.return_value = self._veri()
        result = svc.get_dokumanlar("personel", "111")
        assert len(result) == 2
        assert all(d["EntityId"] == "111" for d in result)

    def test_belge_turu_filtresi(self, svc, reg):
        reg.get("Dokumanlar").get_all.return_value = self._veri()
        result = svc.get_dokumanlar("personel", "111", belge_turu="Diploma")
        assert len(result) == 1
        assert result[0]["BelgeTuru"] == "Diploma"

    def test_eslesme_yok_bos_liste(self, svc, reg):
        reg.get("Dokumanlar").get_all.return_value = self._veri()
        result = svc.get_dokumanlar("personel", "999")
        assert result == []

    def test_repo_hatasi_bos_liste(self, svc, reg):
        reg.get("Dokumanlar").get_all.side_effect = Exception("Hata")
        assert svc.get_dokumanlar("personel", "111") == []


# ─────────────────────────────────────────────────────────────
#  upload_and_save — offline mod
# ─────────────────────────────────────────────────────────────

class TestUploadAndSave:
    def test_offline_mod_local_path_kaydeder(self, svc, reg, tmp_path):
        """
        Offline modda dosya yerel diske kopyalanır,
        DrivePath boş, mode='local' döner.
        """
        test_file = tmp_path / "rapor.pdf"
        test_file.write_bytes(b"PDF content")

        mock_repo = MagicMock()
        reg.get.return_value = mock_repo

        with patch("core.config.AppConfig.is_online_mode", return_value=False), \
             patch("shutil.copy2"), \
             patch("os.makedirs"):
            result = svc.upload_and_save(
                file_path=str(test_file),
                entity_type="personel",
                entity_id="12345678901",
                belge_turu="SaglikRapor",
                folder_name="Saglik_Raporlari",
                doc_type="Personel_Belge",
                custom_name="test_rapor.pdf",
            )

        assert result["ok"] is True
        assert result["mode"] == "local"
        assert result["drive_link"] is None or result["drive_link"] == ""

    def test_dosya_bulunamadiysa_basarisiz(self, svc):
        """Var olmayan dosya yolu → ok=False"""
        result = svc.upload_and_save(
            file_path="/tmp/kesinlikle_yok_12345.pdf",
            entity_type="personel",
            entity_id="111",
            belge_turu="Diploma",
            folder_name="Personel_Diploma",
            doc_type="Personel_Belge",
        )
        assert result["ok"] is False


# ─────────────────────────────────────────────────────────────
#  sil
# ─────────────────────────────────────────────────────────────

class TestSil:
    def test_sil_basarili(self, svc, reg):
        mock_repo = MagicMock()
        reg.get.return_value = mock_repo
        result = svc.sil("personel", "111", "Diploma", "dosya.pdf")
        assert result is True
        mock_repo.delete.assert_called_once()

    def test_sil_hatasi_false(self, svc, reg):
        mock_repo = MagicMock()
        mock_repo.delete.side_effect = Exception("Hata")
        reg.get.return_value = mock_repo
        result = svc.sil("personel", "111", "Diploma", "dosya.pdf")
        assert result is False
