# ui/styles/components.py  ─  REPYS v3 · Medikal Dark-Blue
from ui.styles.colors import DarkTheme as C, Colors


class ComponentStyles:

    PAGE = f"QWidget {{ background-color: {C.BG_PRIMARY}; }}"

    FILTER_PANEL = f"""
        QFrame {{
            background-color: {C.BG_SECONDARY};
            border: 1px solid {C.BORDER_PRIMARY};
            border-radius: 10px;
        }}
    """

    # ── Butonlar ─────────────────────────────────────────────────
    BTN_ACTION = f"""
        QPushButton {{
            background-color: {C.BTN_PRIMARY_BG};
            color: {C.BTN_PRIMARY_TEXT};
            border: none;
            border-radius: 4px;
            padding: 4px 14px;
            font-weight: 700;
        }}
        QPushButton:hover {{ background-color: {C.BTN_PRIMARY_HOVER}; }}
        QPushButton:pressed {{ opacity: 0.8; }}
    """

    BTN_REFRESH = f"""
        QPushButton {{
            background-color: transparent;
            color: {C.TEXT_SECONDARY};
            border: 1px solid {C.BORDER_SECONDARY};
            border-radius: 4px;
            padding: 4px 12px;
            font-weight: 600;
        }}
        QPushButton:hover {{
            background-color: {C.INPUT_BG};
            color: {C.TEXT_PRIMARY};
            border-color: {C.INPUT_BORDER_FOCUS};
        }}
    """

    BTN_FILTER = f"""
        QPushButton {{
            background-color: transparent;
            color: {C.TEXT_SECONDARY};
            border: 1px solid {C.BORDER_SECONDARY};
            border-radius: 4px;
            padding: 4px 12px;
            font-weight: 500;
        }}
        QPushButton:hover {{
            background-color: {C.INPUT_BG};
            color: {C.TEXT_PRIMARY};
        }}
        QPushButton:checked {{
            background-color: rgba(61,142,245,.15);
            color: {C.ACCENT2};
            border-color: {C.ACCENT};
            font-weight: 700;
        }}
    """

    BTN_FILTER_ALL = f"""
        QPushButton {{
            background-color: transparent;
            color: {C.TEXT_SECONDARY};
            border: 1px solid {C.BORDER_STRONG};
            border-radius: 20px;
            padding: 4px 13px;
            font-size: 12px;
        }}
        QPushButton:hover  {{
            background-color: {C.BG_TERTIARY};
            color: {C.TEXT_PRIMARY};
        }}
        QPushButton:checked {{
            background-color: {C.BG_ELEVATED};
            color: {C.TEXT_PRIMARY};
            border-color: {C.BORDER_STRONG};
            font-weight: 600;
        }}
    """

    BTN_CLOSE = f"""
        QPushButton {{
            background-color: transparent;
            color: {C.TEXT_SECONDARY};
            border: 1px solid {C.BORDER_SECONDARY};
            border-radius: 4px;
            padding: 4px 12px;
            font-weight: 600;
        }}
        QPushButton:hover {{
            background-color: rgba(232,85,85,.15);
            color: #e85555;
            border-color: #e85555;
        }}
    """

    BTN_EXCEL = f"""
        QPushButton {{
            background-color: transparent;
            color: {C.TEXT_SECONDARY};
            border: 1px solid {C.BORDER_SECONDARY};
            border-radius: 4px;
            padding: 4px 12px;
            font-weight: 600;
        }}
        QPushButton:hover {{
            background-color: rgba(46,201,142,.15);
            color: #2ec98e;
            border-color: #2ec98e;
        }}
    """

    SAVE_BTN   = BTN_EXCEL
    CANCEL_BTN = BTN_REFRESH
    EDIT_BTN   = BTN_REFRESH
    DANGER_BTN = BTN_CLOSE
    REPORT_BTN = BTN_REFRESH
    PDF_BTN    = BTN_REFRESH
    BACK_BTN   = BTN_REFRESH
    CALC_BTN   = BTN_REFRESH

    # ── Input Alanları ───────────────────────────────────────────
    INPUT_SEARCH = f"""
        QLineEdit {{
            background-color: {C.INPUT_BG};
            border: 1px solid {C.BORDER_SECONDARY};
            border-radius: 4px;
            padding: 6px 10px 6px 30px;
            color: {C.TEXT_PRIMARY};
            font-family: {C.MONOSPACE};
        }}
        QLineEdit:focus {{ border-color: {C.INPUT_BORDER_FOCUS}; }}
        QLineEdit::placeholder {{ color: {C.TEXT_MUTED}; }}
    """

    INPUT_COMBO = f"""
        QComboBox {{
            background-color: {C.INPUT_BG};
            border: 1px solid {C.BORDER_SECONDARY};
            border-radius: 4px;
            padding: 0 9px;
            color: {C.TEXT_PRIMARY};
            font-family: {C.MONOSPACE};
        }}
        QComboBox:focus {{ border-color: {C.INPUT_BORDER_FOCUS}; }}
        QComboBox::drop-down {{ border: none; width: 20px; }}
        QComboBox QAbstractItemView {{
            background-color: {C.BG_SECONDARY};
            border: 1px solid {C.BORDER_PRIMARY};
            color: {C.TEXT_PRIMARY};
            selection-background-color: rgba(61,142,245,.14);
            selection-color: {C.ACCENT2};
            outline: 0;
        }}
    """

    INPUT_FIELD = f"""
        QLineEdit {{
            background-color: {C.INPUT_BG};
            border: 1px solid {C.BORDER_SECONDARY};
            border-radius: 4px;
            padding: 0 9px;
            color: {C.TEXT_PRIMARY};
            font-family: {C.MONOSPACE};
        }}
        QLineEdit:focus {{ border-color: {C.INPUT_BORDER_FOCUS}; }}
        QLineEdit::placeholder {{ color: {C.TEXT_MUTED}; }}
    """

    INPUT_DATE = f"""
        QDateEdit {{
            background-color: {C.INPUT_BG};
            border: 1px solid {C.BORDER_SECONDARY};
            border-radius: 4px;
            padding: 0 9px;
            color: {C.TEXT_PRIMARY};
            font-family: {C.MONOSPACE};
        }}
        QDateEdit:focus {{ border-color: {C.INPUT_BORDER_FOCUS}; }}
    """

    CALENDAR = f"""
        QCalendarWidget {{
            background-color: {C.BG_SECONDARY};
            color: {C.TEXT_PRIMARY};
            border: 1px solid {C.BORDER_PRIMARY};
        }}
        QCalendarWidget QToolButton {{
            background-color: transparent;
            color: {C.TEXT_PRIMARY};
            border: none;
            padding: 4px 8px;
        }}
        QCalendarWidget QMenu {{
            background-color: {C.BG_SECONDARY};
            color: {C.TEXT_PRIMARY};
            border: 1px solid {C.BORDER_PRIMARY};
        }}
        QCalendarWidget QAbstractItemView {{
            background-color: {C.BG_SECONDARY};
            color: {C.TEXT_SECONDARY};
            selection-background-color: rgba(61,142,245,.14);
            selection-color: {C.ACCENT2};
            outline: none;
        }}
    """

    INPUT_TEXT = f"""
        QTextEdit {{
            background-color: {C.INPUT_BG};
            border: 1px solid {C.BORDER_SECONDARY};
            border-radius: 4px;
            padding: 6px;
            color: {C.TEXT_SECONDARY};
            font-family: {C.MONOSPACE};
        }}
        QTextEdit:focus {{ border-color: {C.INPUT_BORDER_FOCUS}; }}
    """

    LABEL_FORM = f"""
        QLabel {{
            color: {C.TEXT_SECONDARY};
            font-size: 11px;
            font-weight: 700;
            background: transparent;
            letter-spacing: 0.04em;
        }}
    """

    LABEL_TITLE = f"""
        QLabel {{
            color: {C.TEXT_PRIMARY};
            font-size: 15px;
            font-weight: 700;
            background: transparent;
        }}
    """

    # ── Tablo ────────────────────────────────────────────────────
    TABLE = f"""
        QTableView, QTableWidget {{
            background-color: {C.BG_SECONDARY};
            border: 1px solid {C.BORDER_PRIMARY};
            gridline-color: transparent;
            color: {C.TEXT_PRIMARY};
            selection-background-color: rgba(61,142,245,.14);
            selection-color: {C.ACCENT2};
            outline: 0;
        }}
        QHeaderView::section {{
            background-color: {C.BG_PRIMARY};
            color: {C.TEXT_MUTED};
            border: none;
            border-bottom: 1px solid {C.BORDER_PRIMARY};
            padding: 7px 10px;
            font-family: {C.MONOSPACE};
            font-size: 8px;
            font-weight: 700;
            letter-spacing: 2px;
        }}
        QTableView::item {{ padding: 4px 10px; color: {C.TEXT_SECONDARY}; }}
        QTableView::item:selected {{ background-color: rgba(61,142,245,.14); color: {C.TEXT_PRIMARY}; }}
    """

    # ── GroupBox ─────────────────────────────────────────────────
    GROUP_BOX = f"""
        QGroupBox {{
            background-color: {C.BG_SECONDARY};
            border: 1px solid {C.BORDER_PRIMARY};
            margin-top: 12px;
            padding-top: 8px;
            color: {C.TEXT_PRIMARY};
            font-weight: 600;
        }}
        QGroupBox::title {{
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 8px;
            color: {C.TEXT_PRIMARY};
            font-weight: 600;
        }}
    """

    SCROLLBAR = f"""
        QScrollBar:vertical {{
            background: transparent; width: 5px; margin: 0;
        }}
        QScrollBar::handle:vertical {{
            background: {C.BORDER_SECONDARY};
            border-radius: 2px; min-height: 20px;
        }}
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
        QScrollBar:horizontal {{
            background: transparent; height: 5px; margin: 0;
        }}
        QScrollBar::handle:horizontal {{
            background: {C.BORDER_SECONDARY};
            border-radius: 2px; min-width: 20px;
        }}
        QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0; }}
    """

    TAB = f"""
        QTabWidget::pane {{
            background-color: {C.BG_SECONDARY};
            border: 1px solid {C.BORDER_PRIMARY};
        }}
        QTabBar::tab {{
            background-color: transparent;
            color: {C.TEXT_SECONDARY};
            border: none;
            border-bottom: 2px solid transparent;
            padding: 6px 12px;
            font-weight: 500;
        }}
        QTabBar::tab:selected {{
            color: {C.ACCENT2};
            border-bottom-color: {C.INPUT_BORDER_FOCUS};
            font-weight: 700;
        }}
    """

    @staticmethod
    def get_status_color(status: str) -> tuple:
        _MAP = {
            "Aktif":              (16,  185, 129, 30),
            "Pasif":              (239, 68,  68,  30),
            "İzinli":             (245, 158, 11,  30),
            "Arızalı":            (239, 68,  68,  30),
            "Bakımda":            (245, 158, 11,  30),
            "Kapalı (Çözüldü)":  (16,  185, 129, 30),
            "Açık":               (239, 68,  68,  30),
            "İşlemde":            (249, 115, 22,  30),
            "Planlandı":          (245, 158, 11,  30),
            "Tamamlandı":         (16,  185, 129, 30),
            "Onaylandı":          (16,  185, 129, 30),
            "Beklemede":          (245, 158, 11,  30),
            "İptal":              (100, 116, 139, 25),
            "Kalibrasyonda":      (168, 85,  247, 30),
            "Parça Bekliyor":     (251, 191, 36,  30),
            "Dış Serviste":       (168, 85,  247, 30),
        }
        return _MAP.get(status, (78, 104, 136, 25))

    @staticmethod
    def get_status_text_color(status: str) -> str:
        _MAP = {
            "Aktif":              "#10b981",
            "Pasif":              "#f87171",
            "İzinli":             "#f59e0b",
            "Arızalı":            "#f87171",
            "Bakımda":            "#f59e0b",
            "Kapalı (Çözüldü)":  "#10b981",
            "Açık":               "#f87171",
            "İşlemde":            "#fb923c",
            "Planlandı":          "#f59e0b",
            "Tamamlandı":         "#10b981",
            "Onaylandı":          "#10b981",
            "Beklemede":          "#f59e0b",
            "İptal":              "#4e6888",
            "Kalibrasyonda":      "#a855f7",
            "Parça Bekliyor":     "#fbbf24",
            "Dış Serviste":       "#a855f7",
        }
        return _MAP.get(status, "#8aa8c8")

    FOOTER_LABEL = f"""
        QLabel {{
            color: {C.TEXT_MUTED};
            font-size: 10px;
            font-weight: 400;
            background: transparent;
        }}
    """

    PROGRESS = f"""
        QProgressBar {{
            background-color: {C.BORDER_SECONDARY};
            border: none;
            border-radius: 1px;
            height: 3px;
            margin: 0px;
            padding: 0px;
        }}
        QProgressBar::chunk {{
            background-color: {C.INPUT_BORDER_FOCUS};
            border-radius: 1px;
        }}
    """

    CONTEXT_MENU = f"""
        QMenu {{
            background-color: {C.BG_SECONDARY};
            color: {C.TEXT_PRIMARY};
            border: 1px solid {C.BORDER_PRIMARY};
            border-radius: 8px;
            padding: 4px 0;
            spacing: 0;
        }}
        QMenu::item {{
            padding: 6px 16px;
            background: transparent;
            border-radius: 0;
        }}
        QMenu::item:selected {{
            background-color: {C.BG_HOVER};
            color: {C.ACCENT2};
        }}
        QMenu::item:pressed {{
            background-color: {C.BG_SELECTED};
        }}
        QMenu::separator {{
            height: 1px;
            background-color: {C.BORDER_SECONDARY};
            margin: 4px 0;
        }}
    """

    INFO_LABEL = f"""
        QLabel {{
            color: {C.TEXT_SECONDARY};
            font-size: 12px;
            font-weight: 500;
            background: transparent;
        }}
    """

    SECTION_LABEL = f"""
        QLabel {{
            color: {C.TEXT_PRIMARY};
            font-size: 13px;
            font-weight: 700;
            background: transparent;
            letter-spacing: 0.02em;
        }}
    """

    MAX_LABEL = f"""
        QLabel {{
            color: {Colors.YELLOW_400};
            font-size: 11px;
            font-style: italic;
            background: transparent;
        }}
    """

    DONEM_LABEL = f"""
        QLabel {{
            color: {C.ACCENT};
            font-size: 13px;
            font-weight: 600;
            background: transparent;
            padding: 4px 8px;
        }}
    """

    # ── Ek Stiller (Personel Modülü) ──────────────────────────────
    LABEL = LABEL_FORM  # Generic etiket

    INPUT = INPUT_FIELD  # Generic input

    COMBO_FILTER = INPUT_COMBO  # Filtre combo box'ları

    SEPARATOR = f"""
        QFrame {{
            background-color: {C.BORDER_SECONDARY};
            height: 1px;
        }}
    """

    SPLITTER = f"""
        QSplitter {{
            background-color: transparent;
        }}
        QSplitter::handle {{
            background-color: {C.BORDER_SECONDARY};
        }}
        QSplitter::handle:hover {{
            background-color: {C.BORDER_STRONG};
        }}
    """

    HEADER_NAME = f"""
        QLabel {{
            color: {C.TEXT_PRIMARY};
            font-size: 14px;
            font-weight: 700;
            background: transparent;
            letter-spacing: 0.01em;
        }}
    """

    PHOTO_AREA = f"""
        QLabel {{
            background-color: {C.BG_TERTIARY};
            border: 2px dashed {C.BORDER_STRONG};
            border-radius: 8px;
            color: {C.TEXT_MUTED};
            font-size: 12px;
        }}
    """

    PHOTO_BTN = f"""
        QPushButton {{
            background-color: {C.ACCENT};
            color: white;
            border: none;
            border-radius: 6px;
            padding: 6px 14px;
            font-size: 11px;
            font-weight: 600;
        }}
        QPushButton:hover {{ background-color: #00a8d8; }}
        QPushButton:pressed {{ background-color: #0090b0; }}
    """

    FILE_BTN = PHOTO_BTN

    REQUIRED_LABEL = f"""
        QLabel {{
            color: {C.TEXT_SECONDARY};
            font-size: 11px;
            font-weight: 700;
            background: transparent;
            letter-spacing: 0.04em;
        }}
        QLabel::before {{
            content: "* ";
            color: #ef4444;
        }}
    """

    DATE = INPUT_DATE

    SPIN = f"""
        QSpinBox {{
            background-color: {C.INPUT_BG};
            border: 1px solid {C.BORDER_SECONDARY};
            border-radius: 4px;
            padding: 0 9px;
            color: {C.TEXT_PRIMARY};
            font-family: {C.MONOSPACE};
        }}
        QSpinBox:focus {{ border-color: {C.INPUT_BORDER_FOCUS}; }}
    """

    STAT_LABEL = f"""
        QLabel {{
            color: {C.TEXT_MUTED};
            font-size: 12px;
            font-weight: 500;
            background: transparent;
        }}
    """

    STAT_VALUE = f"""
        QLabel {{
            color: {C.TEXT_PRIMARY};
            font-size: 16px;
            font-weight: 600;
            background: transparent;
        }}
    """

    STAT_RED = f"""
        QLabel {{
            color: {Colors.RED_400};
            font-size: 16px;
            font-weight: 600;
            background: transparent;
        }}
    """

    STAT_GREEN = f"""
        QLabel {{
            color: {Colors.GREEN_400};
            font-size: 16px;
            font-weight: 600;
            background: transparent;
        }}
    """

    VALUE = f"""
        QLabel {{
            color: {C.TEXT_PRIMARY};
            font-size: 13px;
            font-weight: 500;
            background: transparent;
        }}
    """

    HEADER_DURUM_AKTIF = f"""
        QLabel {{
            background-color: rgba(16,185,129,0.15);
            color: {Colors.GREEN_400};
            border: 1px solid rgba(16,185,129,0.30);
            border-radius: 6px;
            padding: 4px 10px;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.04em;
        }}
    """

    HEADER_DURUM_PASIF = f"""
        QLabel {{
            background-color: rgba(239,68,68,0.15);
            color: {Colors.RED_400};
            border: 1px solid rgba(239,68,68,0.30);
            border-radius: 6px;
            padding: 4px 10px;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.04em;
        }}
    """

    HEADER_DURUM_IZINLI = f"""
        QLabel {{
            background-color: rgba(245,158,11,0.15);
            color: {Colors.YELLOW_400};
            border: 1px solid rgba(245,158,11,0.30);
            border-radius: 6px;
            padding: 4px 10px;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.04em;
        }}
    """

    STAT_HIGHLIGHT = f"""
        QLabel {{
            color: {C.ACCENT};
            font-size: 16px;
            font-weight: 700;
            background: transparent;
        }}
    """

    SECTION_TITLE = f"""
        QLabel {{
            color: {C.TEXT_PRIMARY};
            font-size: 14px;
            font-weight: 700;
            background: transparent;
            padding: 6px 0;
        }}
    """


# ThemeManager için STYLES dict
STYLES = {
    "page":           ComponentStyles.PAGE,
    "filter_panel":   ComponentStyles.FILTER_PANEL,
    "btn_action":     ComponentStyles.BTN_ACTION,
    "btn_refresh":    ComponentStyles.BTN_REFRESH,
    "btn_filter":     ComponentStyles.BTN_FILTER,
    "btn_filter_all": ComponentStyles.BTN_FILTER_ALL,
    "btn_close":      ComponentStyles.BTN_CLOSE,
    "btn_excel":      ComponentStyles.BTN_EXCEL,
    "save_btn":       ComponentStyles.SAVE_BTN,
    "cancel_btn":     ComponentStyles.CANCEL_BTN,
    "edit_btn":       ComponentStyles.EDIT_BTN,
    "danger_btn":     ComponentStyles.DANGER_BTN,
    "report_btn":     ComponentStyles.REPORT_BTN,
    "pdf_btn":        ComponentStyles.PDF_BTN,
    "back_btn":       ComponentStyles.BACK_BTN,
    "calc_btn":       ComponentStyles.CALC_BTN,
    "input_search":   ComponentStyles.INPUT_SEARCH,
    "input_combo":    ComponentStyles.INPUT_COMBO,
    "input_field":    ComponentStyles.INPUT_FIELD,
    "input_date":     ComponentStyles.INPUT_DATE,
    "input_text":     ComponentStyles.INPUT_TEXT,
    "label_form":     ComponentStyles.LABEL_FORM,
    "label_title":    ComponentStyles.LABEL_TITLE,
    "table":          ComponentStyles.TABLE,
    "group_box":      ComponentStyles.GROUP_BOX,
    "scrollbar":      ComponentStyles.SCROLLBAR,
    "tab":            ComponentStyles.TAB,
    "footer_label":   ComponentStyles.FOOTER_LABEL,
    "progress":       ComponentStyles.PROGRESS,
    "context_menu":   ComponentStyles.CONTEXT_MENU,
    "info_label":     ComponentStyles.INFO_LABEL,
    "section_label":  ComponentStyles.SECTION_LABEL,
    "label":          ComponentStyles.LABEL,
    "input":          ComponentStyles.INPUT,
    "separator":      ComponentStyles.SEPARATOR,
    "splitter":       ComponentStyles.SPLITTER,
    "header_name":    ComponentStyles.HEADER_NAME,
    "photo_area":     ComponentStyles.PHOTO_AREA,
    "photo_btn":      ComponentStyles.PHOTO_BTN,
    "file_btn":       ComponentStyles.FILE_BTN,
    "required_label": ComponentStyles.REQUIRED_LABEL,
    "date":           ComponentStyles.DATE,
    "group":          ComponentStyles.GROUP_BOX,
    "spin":           ComponentStyles.SPIN,
    "stat_label":     ComponentStyles.STAT_LABEL,
    "stat_value":     ComponentStyles.STAT_VALUE,
    "stat_red":       ComponentStyles.STAT_RED,
    "stat_green":     ComponentStyles.STAT_GREEN,
    "stat_highlight": ComponentStyles.STAT_HIGHLIGHT,
    "value":          ComponentStyles.VALUE,
    "section_title":  ComponentStyles.SECTION_TITLE,
    "max_label":      ComponentStyles.MAX_LABEL,
    "combo_filter":   ComponentStyles.COMBO_FILTER,
    "donem_label":    ComponentStyles.DONEM_LABEL,
    "header_durum_aktif":  ComponentStyles.HEADER_DURUM_AKTIF,
    "header_durum_pasif":  ComponentStyles.HEADER_DURUM_PASIF,
    "header_durum_izinli": ComponentStyles.HEADER_DURUM_IZINLI,
    # Geriye dönük uyumluluk takma adları
    "refresh_btn":    ComponentStyles.BTN_REFRESH,
    "close_btn":      ComponentStyles.BTN_CLOSE,
    "action_btn":     ComponentStyles.BTN_ACTION,
    "combo":          ComponentStyles.INPUT_COMBO,
    "excel_btn":      ComponentStyles.BTN_EXCEL,
    "search":         ComponentStyles.INPUT_SEARCH,
    "scroll":         ComponentStyles.SCROLLBAR,}