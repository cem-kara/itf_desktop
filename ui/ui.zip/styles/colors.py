# ui/styles/colors.py  ─  REPYS v3 · Medikal Dark-Blue Tema
# ═══════════════════════════════════════════════════════════════
#  Koyu mavi (medical-grade) palette.
#  DarkTheme attribute isimleri KORUNDU — başka dosyada değişiklik yok.
# ═══════════════════════════════════════════════════════════════

class Colors:
    WHITE   = "#ffffff"
    BLACK   = "#000000"

    # Mavi/Lacivert Skalası
    NAVY_950 = "#060d1a"
    NAVY_900 = "#0b1628"
    NAVY_850 = "#0e1e35"
    NAVY_800 = "#112240"
    NAVY_750 = "#152b4f"
    NAVY_700 = "#1a3560"
    NAVY_600 = "#1e4080"
    NAVY_500 = "#1e5fa0"
    NAVY_400 = "#2478c8"
    NAVY_300 = "#4a9be0"
    NAVY_200 = "#7ab8f0"
    NAVY_100 = "#b8d8f8"
    NAVY_50  = "#e8f2fc"

    # Vurgu — Elektrik Mavi (accent)
    CYAN_500  = "#00b4d8"
    CYAN_400  = "#22d3ee"
    CYAN_300  = "#67e8f9"
    CYAN_BG   = "rgba(0,180,216,0.10)"

    # Gri (nötr)
    GRAY_900 = "#111827"
    GRAY_800 = "#1f2937"
    GRAY_700 = "#374151"
    GRAY_600 = "#4b5563"
    GRAY_400 = "#9ca3af"
    GRAY_300 = "#d1d5db"
    GRAY_100 = "#f3f4f6"

    # Durum
    GREEN_600  = "#059669"
    GREEN_500  = "#10b981"
    GREEN_400  = "#34d399"
    GREEN_BG   = "rgba(16,185,129,0.10)"
    RED_600    = "#dc2626"
    RED_500    = "#ef4444"
    RED_400    = "#f87171"
    RED_BG     = "rgba(239,68,68,0.10)"
    YELLOW_500 = "#f59e0b"
    YELLOW_400 = "#fbbf24"
    YELLOW_BG  = "rgba(245,158,11,0.10)"
    ORANGE_500 = "#f97316"
    PURPLE_500 = "#a855f7"
    PURPLE_BG  = "rgba(168,85,247,0.10)"

    # Menu renkleri
    MENU_ACTIVE = "#00b4d8"
    MENU_ITEM   = "#8aa8c8"

    SUCCESS = "#10b981"


class DarkTheme:
    """
    Medikal koyu mavi dark tema — RKE mockup renkleri ile güncellenmiş.
    Tüm attribute isimleri önceki versiyonla birebir aynı.
    """
    # ── Zemin Katmanları ─────────────────────────────────────────
    BG_PRIMARY   = "#0d1117"   # Ana zemin (RKE_BG1)
    BG_SECONDARY = "#121820"   # Panel / kart (RKE_BG2)
    BG_TERTIARY  = "#0d1117"   # İçe gömülü alan, zebra satır (RKE_BG1)
    BG_ELEVATED  = "#1a2030"   # Yükseltilmiş panel, popup (RKE_BG3)
    BG_HOVER     = "rgba(0,180,216,0.06)"
    BG_SELECTED  = "rgba(0,180,216,0.14)"

    # ── Kenarlıklar ──────────────────────────────────────────────
    BORDER_PRIMARY   = "#1e2d3d"    # RKE_BD
    BORDER_SECONDARY = "#253545"    # RKE_BD2
    BORDER_FOCUS     = "#3d8ef5"    # RKE_BLUE
    BORDER_STRONG    = "#253545"    # RKE_BD2

    # ── Metin ────────────────────────────────────────────────────
    TEXT_PRIMARY   = "#e8edf5"   # RKE_TX0 — açık metin
    TEXT_SECONDARY = "#8fa3b8"   # RKE_TX1 — orta metin
    TEXT_MUTED     = "#4d6070"   # RKE_TX2 — koyu metin
    TEXT_DISABLED  = "#263850"   # Devre dışı (korundu)

    # ── Input ────────────────────────────────────────────────────
    INPUT_BG           = "#1a2030"   # RKE_BG3
    INPUT_BORDER       = "#1e2d3d"   # RKE_BD
    INPUT_BORDER_FOCUS = "#3d8ef5"   # RKE_BLUE

    # ── Vurgu (RKE mavi) ───────────────────────────────────────────
    ACCENT    = "#3d8ef5"    # RKE_BLUE — ana vurgu
    ACCENT2   = "#20c0d8"    # RKE_CYAN — açık vurgu
    ACCENT_BG = "rgba(61,142,245,0.12)"  # RKE_BLUE transparanı

    # ── Butonlar ─────────────────────────────────────────────────
    BTN_PRIMARY_BG     = "#3d8ef5"     # RKE_BLUE
    BTN_PRIMARY_TEXT   = "#060d1a"     # (korundu)
    BTN_PRIMARY_HOVER  = "#20c0d8"     # RKE_CYAN
    BTN_PRIMARY_BORDER = "#3d8ef5"     # RKE_BLUE

    BTN_SECONDARY_BG     = "#1a2030"   # Arka plan: RKE_BG3
    BTN_SECONDARY_TEXT   = "#8fa3b8"   # Metin: RKE_TX1
    BTN_SECONDARY_BORDER = "#1e2d3d"   # Border: RKE_BD
    BTN_SECONDARY_HOVER  = "#253545"   # Hover: RKE_BD2

    BTN_DANGER_BG     = "rgba(232,85,85,0.15)"    # RKE_RED rgba
    BTN_DANGER_TEXT   = "#e85555"                 # RKE_RED
    BTN_DANGER_BORDER = "rgba(232,85,85,0.30)"   # RKE_RED rgba açık
    BTN_DANGER_HOVER  = "rgba(232,85,85,0.25)"   # RKE_RED rgba hover

    BTN_SUCCESS_BG     = "rgba(46,201,142,0.15)"   # RKE_GREEN rgba
    BTN_SUCCESS_TEXT   = "#2ec98e"                 # RKE_GREEN
    BTN_SUCCESS_BORDER = "rgba(46,201,142,0.30)"  # RKE_GREEN rgba açık
    BTN_SUCCESS_HOVER  = "rgba(46,201,142,0.25)"  # RKE_GREEN rgba hover

    # ── Durum ────────────────────────────────────────────────────
    STATUS_SUCCESS = "#2ec98e"   # RKE_GREEN
    STATUS_WARNING = "#e8a030"   # RKE_AMBER
    STATUS_ERROR   = "#e85555"   # RKE_RED
    STATUS_INFO    = "#3d8ef5"   # RKE_BLUE

    # ── Badge RGBA (r,g,b,alpha) ──────────────────────────────────
    STATE_ACTIVE  = (16,  185, 129, 35)
    STATE_PASSIVE = (239, 68,  68,  35)
    STATE_LEAVE   = (245, 158, 11,  35)

    # ── RKE Modülü Renkleri (Mockup Renkler) ──────────────────────
    RKE_BG0   = "#070a0e"      # Çok koyu zemin
    RKE_BG1   = "#0d1117"      # Temel zemin
    RKE_BG2   = "#121820"      # İkinci zemin
    RKE_BG3   = "#1a2030"      # Input zemin
    RKE_BD    = "#1e2d3d"      # Border
    RKE_BD2   = "#253545"      # Border açık
    RKE_TX0   = "#e8edf5"      # Metin açık (primer)
    RKE_TX1   = "#8fa3b8"      # Metin orta
    RKE_TX2   = "#4d6070"      # Metin koyu (muted)
    RKE_RED   = "#e85555"      # Kırmızı
    RKE_AMBER = "#e8a030"      # Sarı/turuncu
    RKE_GREEN = "#2ec98e"      # Yeşil
    RKE_BLUE  = "#3d8ef5"      # Mavi
    RKE_CYAN  = "#20c0d8"      # Cyan
    RKE_PURP  = "#a060e8"      # Mor

    # ── RKE Yazı Tipi ──────────────────────────────────
    MONOSPACE = "JetBrains Mono"
