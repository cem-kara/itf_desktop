"""
ArizaService Test Suite — Düzeltilmiş

Tüm metodlar SonucYonetici döndürür:
  get_ariza_listesi / get_ariza_tipleri / vb. → .veri (list)
  kaydet / sil                                → .basarili
"""
import pytest
from unittest.mock import MagicMock
from core.services.ariza_service import ArizaService


@pytest.fixture
def reg():
    return MagicMock()


@pytest.fixture
def svc(reg):
    return ArizaService(reg)


class TestInit:
    def test_none_registry_hata_firlatar(self):
        with pytest.raises(ValueError):
            ArizaService(None)

    def test_registry_saklanir(self, reg):
        s = ArizaService(reg)
        assert s._r is reg


class TestGetArizaListesi:
    def test_bos_liste(self, svc, reg):
        reg.get("Cihaz_Ariza").get_all.return_value = []
        result = svc.get_ariza_listesi()
        assert result.basarili is True
        assert result.veri == []

    def test_tum_liste(self, svc, reg):
        reg.get("Cihaz_Ariza").get_all.return_value = [
            {"Arizaid": "1", "Cihazid": "C01"},
            {"Arizaid": "2", "Cihazid": "C02"},
        ]
        result = svc.get_ariza_listesi()
        assert result.basarili is True
        assert len(result.veri) == 2

    def test_cihaz_filtresi(self, svc, reg):
        reg.get("Cihaz_Ariza").get_all.return_value = [
            {"Arizaid": "1", "Cihazid": "C01"},
            {"Arizaid": "2", "Cihazid": "C02"},
            {"Arizaid": "3", "Cihazid": "C01"},
        ]
        result = svc.get_ariza_listesi(cihaz_id="C01")
        assert result.basarili is True
        assert len(result.veri) == 2
        assert all(r["Cihazid"] == "C01" for r in result.veri)

    def test_cihaz_filtresi_bos_sonuc(self, svc, reg):
        reg.get("Cihaz_Ariza").get_all.return_value = [
            {"Arizaid": "1", "Cihazid": "C01"}
        ]
        result = svc.get_ariza_listesi(cihaz_id="C99")
        assert result.basarili is True
        assert result.veri == []

    def test_repo_hatasi_basarisiz(self, svc, reg):
        reg.get("Cihaz_Ariza").get_all.side_effect = Exception("Hata")
        result = svc.get_ariza_listesi()
        assert result.basarili is False


class TestGetSabitlerListeleri:
    def _sabitler(self):
        return [
            {"Kod": "ArızaTipi",   "MenuEleman": "Mekanik"},
            {"Kod": "ArızaTipi",   "MenuEleman": "Elektrik"},
            {"Kod": "ArızaTipi",   "MenuEleman": "Elektrik"},  # tekrar
            {"Kod": "ArızaDurumu", "MenuEleman": "Açık"},
            {"Kod": "ArızaDurumu", "MenuEleman": "Kapalı"},
            {"Kod": "Oncelik",     "MenuEleman": "Yüksek"},
            {"Kod": "Oncelik",     "MenuEleman": "Düşük"},
            {"Kod": "BaskaBir",    "MenuEleman": "Gürültü"},
        ]

    def test_ariza_tipleri(self, svc, reg):
        reg.get("Sabitler").get_all.return_value = self._sabitler()
        result = svc.get_ariza_tipleri()
        assert result.basarili is True
        assert "Mekanik" in result.veri
        assert "Elektrik" in result.veri

    def test_ariza_tipleri_tekrar_yok(self, svc, reg):
        reg.get("Sabitler").get_all.return_value = self._sabitler()
        result = svc.get_ariza_tipleri()
        assert result.basarili is True
        assert result.veri.count("Elektrik") == 1

    def test_ariza_tipleri_alfabetik(self, svc, reg):
        reg.get("Sabitler").get_all.return_value = self._sabitler()
        result = svc.get_ariza_tipleri()
        assert result.basarili is True
        assert result.veri == sorted(result.veri)

    def test_ariza_durumlari(self, svc, reg):
        reg.get("Sabitler").get_all.return_value = self._sabitler()
        result = svc.get_ariza_durumlari()
        assert result.basarili is True
        assert "Açık" in result.veri
        assert "Gürültü" not in result.veri

    def test_oncelik_seviyeleri(self, svc, reg):
        reg.get("Sabitler").get_all.return_value = self._sabitler()
        result = svc.get_oncelik_seviyeleri()
        assert result.basarili is True
        assert "Yüksek" in result.veri

    def test_sabitler_hatasi_basarisiz(self, svc, reg):
        reg.get("Sabitler").get_all.side_effect = Exception("Hata")
        assert svc.get_ariza_tipleri().basarili is False
        assert svc.get_ariza_durumlari().basarili is False
        assert svc.get_oncelik_seviyeleri().basarili is False


class TestCihaz:
    def test_cihaz_listesi(self, svc, reg):
        reg.get("Cihazlar").get_all.return_value = [
            {"Cihazid": "C01"}, {"Cihazid": "C02"}
        ]
        result = svc.get_cihaz_listesi()
        assert result.basarili is True
        assert len(result.veri) == 2

    def test_tek_cihaz(self, svc, reg):
        mock_repo = MagicMock()
        mock_repo.get_by_pk.return_value = {"Cihazid": "C01", "Adi": "CT"}
        reg.get.return_value = mock_repo
        result = svc.get_cihaz("C01")
        assert result.basarili is True
        assert result.veri["Adi"] == "CT"

    def test_cihaz_bulunamadi(self, svc, reg):
        mock_repo = MagicMock()
        mock_repo.get_by_pk.return_value = None
        reg.get.return_value = mock_repo
        result = svc.get_cihaz("YOK")
        assert result.basarili is True
        assert result.veri is None


class TestKaydet:
    def test_insert(self, svc, reg):
        mock_repo = MagicMock()
        reg.get.return_value = mock_repo
        veri = {"Cihazid": "C01", "Aciklama": "Arıza var"}
        result = svc.kaydet(veri, guncelle=False)
        assert result.basarili is True
        mock_repo.insert.assert_called_once_with(veri)

    def test_update_basarili(self, svc, reg):
        mock_repo = MagicMock()
        reg.get.return_value = mock_repo
        veri = {"Arizaid": "42", "Durum": "Kapalı"}
        result = svc.kaydet(veri, guncelle=True)
        assert result.basarili is True
        mock_repo.update.assert_called_once_with("42", veri)

    def test_update_pk_yoksa_basarisiz(self, svc, reg):
        result = svc.kaydet({"Aciklama": "PK yok"}, guncelle=True)
        assert result.basarili is False

    def test_insert_db_hatasi(self, svc, reg):
        mock_repo = MagicMock()
        mock_repo.insert.side_effect = Exception("Hata")
        reg.get.return_value = mock_repo
        result = svc.kaydet({"Cihazid": "C01"}, guncelle=False)
        assert result.basarili is False


class TestSil:
    def test_sil_basarili(self, svc, reg):
        mock_repo = MagicMock()
        reg.get.return_value = mock_repo
        result = svc.sil("42")
        assert result.basarili is True
        mock_repo.delete.assert_called_once_with("42")

    def test_sil_hatasi(self, svc, reg):
        mock_repo = MagicMock()
        mock_repo.delete.side_effect = Exception("Hata")
        reg.get.return_value = mock_repo
        result = svc.sil("42")
        assert result.basarili is False
