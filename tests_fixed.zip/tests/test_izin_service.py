"""
IzinService Test Suite — Düzeltilmiş

Tüm metodlar SonucYonetici döndürür:
  .basarili (bool), .veri (Any), .mesaj (str)

validate_izin_sure_limit → SonucYonetici (tuple DEĞİL)
insert_izin_giris        → SonucYonetici (ValueError fırlatmaz)
get_izin_listesi         → SonucYonetici (.veri list)
get_izin_tipleri         → SonucYonetici (.veri list)
kaydet / iptal_et        → SonucYonetici
"""
import pytest
from unittest.mock import MagicMock
from datetime import date, timedelta
from typing import Any, cast
from core.services.izin_service import IzinService


# ─────────────────────────────────────────────────────────────
#  Fixture'lar
# ─────────────────────────────────────────────────────────────

@pytest.fixture
def reg():
    return MagicMock()


@pytest.fixture
def svc(reg):
    return IzinService(reg)


# ─────────────────────────────────────────────────────────────
#  Başlatma
# ─────────────────────────────────────────────────────────────

class TestInit:
    def test_none_registry_hata_firlatar(self):
        with pytest.raises(ValueError):
            IzinService(cast(Any, None))

    def test_registry_saklanir(self, reg):
        s = IzinService(reg)
        assert s._r is reg


# ─────────────────────────────────────────────────────────────
#  should_set_pasif — saf bool döndürür, SonucYonetici değil
# ─────────────────────────────────────────────────────────────

class TestShouldSetPasif:

    def test_31_gun_pasif_olmali(self, svc):
        assert svc.should_set_pasif("Yıllık İzin", 31) is True

    def test_30_gun_pasif_olmamali(self, svc):
        assert svc.should_set_pasif("Yıllık İzin", 30) is False

    def test_29_gun_pasif_olmamali(self, svc):
        assert svc.should_set_pasif("Yıllık İzin", 29) is False

    def test_1_gun_pasif_olmamali(self, svc):
        assert svc.should_set_pasif("Yıllık İzin", 1) is False

    def test_0_gun_pasif_olmamali(self, svc):
        assert svc.should_set_pasif("Yıllık İzin", 0) is False

    def test_ucretsiz_izin_1_gun_pasif_olmali(self, svc):
        assert svc.should_set_pasif("Ücretsiz İzin", 1) is True

    def test_ucretsiz_izin_ascii_1_gun_pasif_olmali(self, svc):
        assert svc.should_set_pasif("Ucretsiz Izin", 1) is True

    def test_ayliksiz_izin_1_gun_pasif_olmali(self, svc):
        assert svc.should_set_pasif("Aylıksız İzin", 1) is True

    def test_ayliksiz_izin_kucuk_harf(self, svc):
        assert svc.should_set_pasif("aylıksız izin", 1) is True

    def test_ayliksiz_bosluklu(self, svc):
        assert svc.should_set_pasif("  Aylıksız İzin  ", 1) is True

    def test_yillik_izin_30_gun_pasif_olmamali(self, svc):
        assert svc.should_set_pasif("Yıllık İzin", 30) is False

    def test_mazeret_izin_5_gun_pasif_olmamali(self, svc):
        assert svc.should_set_pasif("Mazeret İzni", 5) is False

    def test_none_izin_tipi(self, svc):
        assert svc.should_set_pasif(None, 5) is False

    def test_bos_izin_tipi(self, svc):
        assert svc.should_set_pasif("", 5) is False

    def test_31_gun_ve_ucretsiz_birlikte(self, svc):
        assert svc.should_set_pasif("Ücretsiz İzin", 31) is True


# ─────────────────────────────────────────────────────────────
#  get_izin_listesi  →  SonucYonetici
# ─────────────────────────────────────────────────────────────

class TestGetIzinListesi:
    def _veri(self):
        return [
            {"Izinid": "1", "TC": "111", "Ay": "1", "Yil": "2026"},
            {"Izinid": "2", "TC": "222", "Ay": "1", "Yil": "2026"},
            {"Izinid": "3", "TC": "111", "Ay": "2", "Yil": "2026"},
            {"Izinid": "4", "TC": "111", "Ay": "1", "Yil": "2025"},
        ]

    def test_tum_liste(self, svc, reg):
        reg.get("Izin_Giris").get_all.return_value = self._veri()
        result = svc.get_izin_listesi()
        assert result.basarili is True
        assert len(result.veri) == 4

    def test_tc_filtresi(self, svc, reg):
        reg.get("Izin_Giris").get_all.return_value = self._veri()
        result = svc.get_izin_listesi(tc="111")
        assert result.basarili is True
        assert len(result.veri) == 3

    def test_ay_yil_filtresi(self, svc, reg):
        reg.get("Izin_Giris").get_all.return_value = self._veri()
        result = svc.get_izin_listesi(ay=1, yil=2026)
        assert result.basarili is True
        assert len(result.veri) == 2

    def test_repo_hatasi_basarisiz(self, svc, reg):
        reg.get("Izin_Giris").get_all.side_effect = Exception("Hata")
        result = svc.get_izin_listesi()
        assert result.basarili is False


# ─────────────────────────────────────────────────────────────
#  get_izin_tipleri  →  SonucYonetici
# ─────────────────────────────────────────────────────────────

class TestGetIzinTipleri:
    def test_tipleri_getirir(self, svc, reg):
        reg.get("Sabitler").get_all.return_value = [
            {"Kod": "Izin_Tipi", "MenuEleman": "Yıllık İzin"},
            {"Kod": "Izin_Tipi", "MenuEleman": "Mazeret İzni"},
            {"Kod": "BaskaBir",  "MenuEleman": "Dahil Edilmez"},
        ]
        result = svc.get_izin_tipleri()
        assert result.basarili is True
        assert "Yıllık İzin" in result.veri
        assert "Mazeret İzni" in result.veri
        assert "Dahil Edilmez" not in result.veri

    def test_tekrarlar_temizlenir(self, svc, reg):
        reg.get("Sabitler").get_all.return_value = [
            {"Kod": "Izin_Tipi", "MenuEleman": "Yıllık İzin"},
            {"Kod": "Izin_Tipi", "MenuEleman": "Yıllık İzin"},
        ]
        result = svc.get_izin_tipleri()
        assert result.basarili is True
        assert result.veri.count("Yıllık İzin") == 1

    def test_alfabetik_sirali(self, svc, reg):
        reg.get("Sabitler").get_all.return_value = [
            {"Kod": "Izin_Tipi", "MenuEleman": "Ücretli"},
            {"Kod": "Izin_Tipi", "MenuEleman": "Aylıksız"},
        ]
        result = svc.get_izin_tipleri()
        assert result.basarili is True
        assert result.veri == sorted(result.veri)


# ─────────────────────────────────────────────────────────────
#  kaydet  →  SonucYonetici
# ─────────────────────────────────────────────────────────────

class TestKaydet:
    def test_insert(self, svc, reg):
        mock_repo = MagicMock()
        reg.get.return_value = mock_repo
        veri = {"TC": "111", "IzinTipi": "Yıllık İzin", "Gun": 5}
        result = svc.kaydet(veri, guncelle=False)
        assert result.basarili is True
        mock_repo.insert.assert_called_once_with(veri)

    def test_update_basarili(self, svc, reg):
        mock_repo = MagicMock()
        reg.get.return_value = mock_repo
        veri = {"Izinid": "7", "Durum": "Onaylı"}
        result = svc.kaydet(veri, guncelle=True)
        assert result.basarili is True
        mock_repo.update.assert_called_once_with("7", veri)

    def test_update_pk_yoksa_basarisiz(self, svc, reg):
        result = svc.kaydet({"IzinTipi": "Yıllık İzin"}, guncelle=True)
        assert result.basarili is False

    def test_db_hatasi_basarisiz(self, svc, reg):
        mock_repo = MagicMock()
        mock_repo.insert.side_effect = Exception("Hata")
        reg.get.return_value = mock_repo
        result = svc.kaydet({"TC": "111"}, guncelle=False)
        assert result.basarili is False


# ─────────────────────────────────────────────────────────────
#  iptal_et  →  SonucYonetici
# ─────────────────────────────────────────────────────────────

class TestIptalEt:
    def test_iptal_basarili(self, svc, reg):
        mock_repo = MagicMock()
        reg.get.return_value = mock_repo
        result = svc.iptal_et("7")
        assert result.basarili is True
        mock_repo.delete.assert_called_once_with("7")

    def test_iptal_hatasi(self, svc, reg):
        mock_repo = MagicMock()
        mock_repo.delete.side_effect = Exception("Hata")
        reg.get.return_value = mock_repo
        result = svc.iptal_et("7")
        assert result.basarili is False


# ─────────────────────────────────────────────────────────────
#  Yıllık Hak Hesaplama  →  float (SonucYonetici değil)
# ─────────────────────────────────────────────────────────────

class TestHesaplaYillikHak:
    def test_1_yildan_az_hizmet_0_gun(self, svc):
        baslama = (date.today() - timedelta(days=200)).isoformat()
        assert svc.hesapla_yillik_hak(baslama) == 0.0

    def test_1_ile_10_yil_arasi_20_gun(self, svc):
        t = date.today()
        baslama = date(t.year - 5, t.month, min(t.day, 28)).isoformat()
        assert svc.hesapla_yillik_hak(baslama) == 20.0

    def test_10_yil_dahil_20_gun(self, svc):
        t = date.today()
        baslama = date(t.year - 10, t.month, min(t.day, 28)).isoformat()
        assert svc.hesapla_yillik_hak(baslama) == 20.0

    def test_10_yildan_fazla_30_gun(self, svc):
        t = date.today()
        baslama = date(t.year - 11, t.month, min(t.day, 28)).isoformat()
        assert svc.hesapla_yillik_hak(baslama) == 30.0

    def test_gecersiz_tarih_0_gun(self, svc):
        assert svc.hesapla_yillik_hak("gecersiz") == 0.0


# ─────────────────────────────────────────────────────────────
#  Izin_Bilgi oluşturma / güncelleme  →  SonucYonetici
# ─────────────────────────────────────────────────────────────

class TestCreateOrUpdateIzinBilgi:
    def test_yeni_kayit_insert_yapar(self, svc, reg):
        repo = MagicMock()
        repo.get_by_id.return_value = None
        reg.get.return_value = repo

        result = svc.create_or_update_izin_bilgi(
            tc="12345678901", ad_soyad="Test Kisi", baslama_tarihi="2015-01-01"
        )
        assert result.basarili is True
        repo.insert.assert_called_once()
        payload = repo.insert.call_args[0][0]
        assert payload["TCKimlik"] == "12345678901"

    def test_mevcut_kayit_update_yapar(self, svc, reg):
        repo = MagicMock()
        repo.get_by_id.return_value = {"TCKimlik": "12345678901"}
        reg.get.return_value = repo

        result = svc.create_or_update_izin_bilgi(
            tc="12345678901", ad_soyad="Test Kisi", baslama_tarihi="2015-01-01"
        )
        assert result.basarili is True
        repo.update.assert_called_once()

    def test_tc_bos_ise_basarisiz(self, svc):
        result = svc.create_or_update_izin_bilgi("", "Test", "2015-01-01")
        assert result.basarili is False

    def test_sayisal_alanlar_none_normalize_edilir(self, svc, reg):
        repo = MagicMock()
        repo.get_by_id.return_value = None
        reg.get.return_value = repo

        svc.hesapla_yillik_hak = MagicMock(return_value=None)

        result = svc.create_or_update_izin_bilgi("12345678901", "Test", "")
        assert result.basarili is True
        payload = repo.insert.call_args[0][0]
        assert payload["YillikKalan"] == 0.0
        assert payload["SuaKullanilabilirHak"] == 0.0


# ─────────────────────────────────────────────────────────────
#  get_izin_max_gun  →  int | None (SonucYonetici değil)
# ─────────────────────────────────────────────────────────────

class TestGetIzinMaxGun:
    def _mock_reg(self, reg, yillik_kalan=None, sua_hak=None, sabitler=None):
        izin_repo  = MagicMock()
        sabit_repo = MagicMock()
        bilgi = {}
        if yillik_kalan is not None:
            bilgi["YillikKalan"] = yillik_kalan
        if sua_hak is not None:
            bilgi["SuaKullanilabilirHak"] = sua_hak
        izin_repo.get_by_id.return_value = bilgi
        sabit_repo.get_all.return_value = sabitler or []
        reg.get.side_effect = lambda name: izin_repo if name == "Izin_Bilgi" else sabit_repo

    def test_yillik_izin_kalan_kadar(self, svc, reg):
        self._mock_reg(reg, yillik_kalan=50)
        assert svc.get_izin_max_gun("111", "Yıllık İzin") == 50

    def test_yillik_izin_max_60_cap(self, svc, reg):
        self._mock_reg(reg, yillik_kalan=70)
        assert svc.get_izin_max_gun("111", "Yıllık İzin") == 60

    def test_sua_izin_sua_kullanilabilir_hak(self, svc, reg):
        self._mock_reg(reg, sua_hak=7)
        assert svc.get_izin_max_gun("111", "Şua İzni") == 7

    def test_diger_izin_sabitler_aciklama_sayisal(self, svc, reg):
        self._mock_reg(reg, sabitler=[
            {"Kod": "İzin_Tipi", "MenuEleman": "Babalık İzni", "Aciklama": "10 gün"}
        ])
        assert svc.get_izin_max_gun("111", "Babalık İzni") == 10

    def test_diger_izin_aciklama_bos_limitsiz(self, svc, reg):
        self._mock_reg(reg, sabitler=[
            {"Kod": "İzin_Tipi", "MenuEleman": "Özel İzin", "Aciklama": ""}
        ])
        assert svc.get_izin_max_gun("111", "Özel İzin") is None


# ─────────────────────────────────────────────────────────────
#  validate_izin_sure_limit  →  SonucYonetici  (tuple DEĞİL)
# ─────────────────────────────────────────────────────────────

class TestValidateIzinSureLimit:
    def _mock_reg(self, reg, yillik_kalan=None, sabitler=None):
        izin_repo  = MagicMock()
        sabit_repo = MagicMock()
        bilgi = {}
        if yillik_kalan is not None:
            bilgi["YillikKalan"] = yillik_kalan
        izin_repo.get_by_id.return_value = bilgi
        sabit_repo.get_all.return_value = sabitler or []
        reg.get.side_effect = lambda name: izin_repo if name == "Izin_Bilgi" else sabit_repo

    def test_gun_sifir_engellenir(self, svc, reg):
        self._mock_reg(reg)
        sonuc = svc.validate_izin_sure_limit("111", "Yıllık İzin", 0)
        assert sonuc.basarili is False
        assert "0" in sonuc.mesaj

    def test_limit_yoksa_basarili(self, svc, reg):
        self._mock_reg(reg, sabitler=[
            {"Kod": "İzin_Tipi", "MenuEleman": "Limitsiz İzin", "Aciklama": ""}
        ])
        sonuc = svc.validate_izin_sure_limit("111", "Limitsiz İzin", 120)
        assert sonuc.basarili is True

    def test_limit_asimi_basarisiz(self, svc, reg):
        """70 gün kalan varken 61 gün → max 60 limitini aşar"""
        self._mock_reg(reg, yillik_kalan=70)
        sonuc = svc.validate_izin_sure_limit("111", "Yıllık İzin", 61)
        assert sonuc.basarili is False
        assert "60" in sonuc.mesaj

    def test_limit_icinde_basarili(self, svc, reg):
        self._mock_reg(reg, yillik_kalan=25)
        sonuc = svc.validate_izin_sure_limit("111", "Yıllık İzin", 20)
        assert sonuc.basarili is True


# ─────────────────────────────────────────────────────────────
#  insert_izin_giris limit enforcement  →  SonucYonetici
# ─────────────────────────────────────────────────────────────

class TestInsertIzinGirisLimitEnforcement:
    def _mock_reg(self, reg, yillik_kalan):
        izin_bilgi_repo = MagicMock()
        sabit_repo      = MagicMock()
        giris_repo      = MagicMock()
        izin_bilgi_repo.get_by_id.return_value = {"YillikKalan": yillik_kalan}
        sabit_repo.get_all.return_value = []

        def _get(name):
            if name == "Izin_Bilgi": return izin_bilgi_repo
            if name == "Sabitler":   return sabit_repo
            if name == "Izin_Giris": return giris_repo
            return MagicMock()

        reg.get.side_effect = _get
        return giris_repo

    def test_limit_asiminda_insert_yapilmaz(self, svc, reg):
        """70 kalan iken 61 gün: max 60 → limit aşımı, insert yapılmamalı"""
        giris_repo = self._mock_reg(reg, yillik_kalan=70)
        result = svc.insert_izin_giris({
            "Personelid": "111", "IzinTipi": "Yıllık İzin", "Gun": 61
        })
        assert result.basarili is False
        giris_repo.insert.assert_not_called()

    def test_limit_icindeyse_insert_yapar(self, svc, reg):
        giris_repo = self._mock_reg(reg, yillik_kalan=25)
        kayit = {"Personelid": "111", "IzinTipi": "Yıllık İzin", "Gun": 20}
        result = svc.insert_izin_giris(kayit)
        assert result.basarili is True
        giris_repo.insert.assert_called_once_with(kayit)


# ─────────────────────────────────────────────────────────────
#  İzin Çakışma Kontrolü  →  bool (SonucYonetici değil)
# ─────────────────────────────────────────────────────────────

class TestIzinCakismaKontrolu:
    def _kayit(self, pid, bas, bit, durum="Onaylandı"):
        return {"Izinid": "A1", "Personelid": pid,
                "BaslamaTarihi": bas, "BitisTarihi": bit, "Durum": durum}

    def test_tarih_kesisirse_true(self, svc, reg):
        reg.get("Izin_Giris").get_all.return_value = [
            self._kayit("111", "2026-03-10", "2026-03-15")
        ]
        assert svc.has_izin_cakisma("111", "2026-03-14", "2026-03-20") is True

    def test_tarih_kesismezse_false(self, svc, reg):
        reg.get("Izin_Giris").get_all.return_value = [
            self._kayit("111", "2026-03-10", "2026-03-15")
        ]
        assert svc.has_izin_cakisma("111", "2026-03-16", "2026-03-18") is False

    def test_farkli_personel_false(self, svc, reg):
        reg.get("Izin_Giris").get_all.return_value = [
            self._kayit("222", "2026-03-10", "2026-03-15")
        ]
        assert svc.has_izin_cakisma("111", "2026-03-12", "2026-03-13") is False

    def test_iptal_kayit_dikkate_alinmaz(self, svc, reg):
        reg.get("Izin_Giris").get_all.return_value = [
            self._kayit("111", "2026-03-10", "2026-03-15", durum="İptal")
        ]
        assert svc.has_izin_cakisma("111", "2026-03-12", "2026-03-13") is False

    def test_sinir_gunde_dokunma_cakisma(self, svc, reg):
        reg.get("Izin_Giris").get_all.return_value = [
            self._kayit("111", "2026-03-10", "2026-03-15")
        ]
        assert svc.has_izin_cakisma("111", "2026-03-15", "2026-03-18") is True

    def test_bitis_bos_baslama_ile_ayni(self, svc, reg):
        reg.get("Izin_Giris").get_all.return_value = [
            self._kayit("111", "2026-03-10", "", durum="Onaylandı")
        ]
        assert svc.has_izin_cakisma("111", "2026-03-10", "2026-03-10") is True

    def test_ignore_izin_id_kendisini_haric_tutar(self, svc, reg):
        reg.get("Izin_Giris").get_all.return_value = [
            self._kayit("111", "2026-03-10", "2026-03-15")
        ]
        assert svc.has_izin_cakisma("111", "2026-03-12", "2026-03-14", ignore_izin_id="A1") is False

    def test_gecersiz_tarih_false(self, svc, reg):
        reg.get("Izin_Giris").get_all.return_value = []
        assert svc.has_izin_cakisma("111", "gecersiz", "2026-03-14") is False


# ─────────────────────────────────────────────────────────────
#  657 SK md.102 — Birleşik Yıllık İzin (max 60 gün)
# ─────────────────────────────────────────────────────────────

class TestBirlesikYillikIzin:
    def _mock_reg(self, reg, yillik_kalan):
        izin_repo  = MagicMock()
        sabit_repo = MagicMock()
        izin_repo.get_by_id.return_value = {"YillikKalan": yillik_kalan}
        sabit_repo.get_all.return_value = []
        reg.get.side_effect = lambda name: izin_repo if name == "Izin_Bilgi" else sabit_repo

    def test_50_gun_kalan_max_50(self, svc, reg):
        self._mock_reg(reg, 50)
        assert svc.get_izin_max_gun("111", "Yıllık İzin") == 50
        sonuc = svc.validate_izin_sure_limit("111", "Yıllık İzin", 50)
        assert sonuc.basarili is True

    def test_60_gun_kalan_max_60(self, svc, reg):
        self._mock_reg(reg, 60)
        assert svc.get_izin_max_gun("111", "Yıllık İzin") == 60
        sonuc = svc.validate_izin_sure_limit("111", "Yıllık İzin", 60)
        assert sonuc.basarili is True

    def test_70_gun_kalan_max_60_cap(self, svc, reg):
        self._mock_reg(reg, 70)
        assert svc.get_izin_max_gun("111", "Yıllık İzin") == 60
        sonuc_60 = svc.validate_izin_sure_limit("111", "Yıllık İzin", 60)
        assert sonuc_60.basarili is True
        sonuc_61 = svc.validate_izin_sure_limit("111", "Yıllık İzin", 61)
        assert sonuc_61.basarili is False

    def test_25_gun_kalan_max_25(self, svc, reg):
        self._mock_reg(reg, 25)
        assert svc.get_izin_max_gun("111", "Yıllık İzin") == 25
        assert svc.validate_izin_sure_limit("111", "Yıllık İzin", 26).basarili is False

    def test_35_gun_izin_gecerli(self, svc, reg):
        self._mock_reg(reg, 40)
        sonuc = svc.validate_izin_sure_limit("111", "Yıllık İzin", 35)
        assert sonuc.basarili is True


# ─────────────────────────────────────────────────────────────
#  657 SK md.102 — Devir Zamanaşımı
# ─────────────────────────────────────────────────────────────

class TestDevirZamanasimi:
    def test_devir_belgelenmis(self):
        assert True  # Manuel test dokümantasyonu

    def test_sample_devir_calculations(self, svc):
        test_cases = [
            (35, 20, 20), (65, 20, 20), (55, 30, 30),
            (40, 20, 20), (15, 20, 15), (80, 30, 30),
        ]
        for kalan, hakedis, beklenen in test_cases:
            max_devir   = hakedis * 2
            hesaplanan  = min(kalan, hakedis, max_devir)
            assert hesaplanan == beklenen
