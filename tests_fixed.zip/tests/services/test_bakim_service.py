"""
BakimService Test Suite — Düzeltilmiş

Tüm metodlar SonucYonetici döndürür:
  get_bakim_listesi   → .veri (list)
  get_bakim_tipleri   → .veri (list)
  get_cihaz_listesi   → .veri (list)
  get_cihaz           → .veri (dict | None)
  kaydet / sil        → .basarili
"""
import pytest
from unittest.mock import MagicMock
from core.services.bakim_service import BakimService


@pytest.fixture
def reg():
    return MagicMock()


@pytest.fixture
def svc(reg):
    return BakimService(reg)


class TestInit:
    def test_none_registry_hata_firlatar(self):
        with pytest.raises(ValueError):
            BakimService(None)

    def test_registry_saklanir(self, reg):
        s = BakimService(reg)
        assert s._r is reg


class TestGetBakimListesi:
    def test_bos_liste(self, svc, reg):
        reg.get("Periyodik_Bakim").get_all.return_value = []
        result = svc.get_bakim_listesi()
        assert result.basarili is True
        assert result.veri == []

    def test_tarih_sirali_desc(self, svc, reg):
        reg.get("Periyodik_Bakim").get_all.return_value = [
            {"Planid": 1, "PlanlananTarih": "2026-01-15"},
            {"Planid": 2, "PlanlananTarih": "2026-02-10"},
            {"Planid": 3, "PlanlananTarih": "2026-01-01"},
        ]
        result = svc.get_bakim_listesi()
        assert result.basarili is True
        assert result.veri[0]["Planid"] == 2   # en yeni
        assert result.veri[2]["Planid"] == 3   # en eski

    def test_cihaz_id_filtresi(self, svc, reg):
        reg.get("Periyodik_Bakim").get_all.return_value = [
            {"Planid": 1, "Cihazid": "CIH001", "PlanlananTarih": "2026-01-01"},
            {"Planid": 2, "Cihazid": "CIH002", "PlanlananTarih": "2026-02-01"},
            {"Planid": 3, "Cihazid": "CIH001", "PlanlananTarih": "2026-03-01"},
        ]
        result = svc.get_bakim_listesi(cihaz_id="CIH001")
        assert result.basarili is True
        assert len(result.veri) == 2
        assert all(r["Cihazid"] == "CIH001" for r in result.veri)

    def test_repo_hatasi_basarisiz(self, svc, reg):
        reg.get("Periyodik_Bakim").get_all.side_effect = Exception("Hata")
        result = svc.get_bakim_listesi()
        assert result.basarili is False


class TestGetBakimTipleri:
    def test_turler_getirir(self, svc, reg):
        reg.get("Sabitler").get_all.return_value = [
            {"Kod": "BakimTipi", "MenuEleman": "Yağlama"},
            {"Kod": "BakimTipi", "MenuEleman": "Kontrol"},
            {"Kod": "DigerKod",  "MenuEleman": "Dahil Edilmez"},
        ]
        result = svc.get_bakim_tipleri()
        assert result.basarili is True
        assert "Yağlama" in result.veri
        assert "Kontrol" in result.veri
        assert "Dahil Edilmez" not in result.veri

    def test_alfabetik_sirali(self, svc, reg):
        reg.get("Sabitler").get_all.return_value = [
            {"Kod": "BakimTipi", "MenuEleman": "Zincir"},
            {"Kod": "BakimTipi", "MenuEleman": "Arge"},
        ]
        result = svc.get_bakim_tipleri()
        assert result.basarili is True
        assert result.veri == sorted(result.veri)

    def test_tekrarlar_temizlenir(self, svc, reg):
        reg.get("Sabitler").get_all.return_value = [
            {"Kod": "BakimTipi", "MenuEleman": "Yağlama"},
            {"Kod": "BakimTipi", "MenuEleman": "Yağlama"},
        ]
        result = svc.get_bakim_tipleri()
        assert result.basarili is True
        assert result.veri.count("Yağlama") == 1


class TestGetCihazListesi:
    def test_cihaz_listesi(self, svc, reg):
        reg.get("Cihazlar").get_all.return_value = [
            {"Cihazid": "C01"}, {"Cihazid": "C02"}
        ]
        result = svc.get_cihaz_listesi()
        assert result.basarili is True
        assert len(result.veri) == 2

    def test_tek_cihaz(self, svc, reg):
        reg.get("Cihazlar").get_by_pk.return_value = {"Cihazid": "C01", "Adi": "CT"}
        result = svc.get_cihaz("C01")
        assert result.basarili is True
        assert result.veri["Adi"] == "CT"

    def test_cihaz_bulunamadi(self, svc, reg):
        reg.get("Cihazlar").get_by_pk.return_value = None
        result = svc.get_cihaz("YOK")
        assert result.basarili is True
        assert result.veri is None


class TestKaydet:
    def test_insert(self, svc, reg):
        mock_repo = MagicMock()
        reg.get.return_value = mock_repo
        veri = {"Cihazid": "C01", "PlanlananTarih": "2026-01-15"}
        result = svc.kaydet(veri, guncelle=False)
        assert result.basarili is True
        mock_repo.insert.assert_called_once_with(veri)

    def test_update(self, svc, reg):
        mock_repo = MagicMock()
        reg.get.return_value = mock_repo
        veri = {"Planid": "1", "BakimTipi": "Kontrol"}
        result = svc.kaydet(veri, guncelle=True)
        assert result.basarili is True
        mock_repo.update.assert_called_once_with("1", veri)

    def test_update_planid_yoksa_basarisiz(self, svc, reg):
        result = svc.kaydet({"Cihazid": "C01"}, guncelle=True)
        assert result.basarili is False

    def test_db_hatasi_basarisiz(self, svc, reg):
        mock_repo = MagicMock()
        mock_repo.insert.side_effect = Exception("Hata")
        reg.get.return_value = mock_repo
        result = svc.kaydet({"Cihazid": "C01"}, guncelle=False)
        assert result.basarili is False


class TestSil:
    def test_sil_basarili(self, svc, reg):
        mock_repo = MagicMock()
        reg.get.return_value = mock_repo
        result = svc.sil("1")
        assert result.basarili is True
        mock_repo.delete.assert_called_once_with("1")

    def test_sil_hatasi(self, svc, reg):
        mock_repo = MagicMock()
        mock_repo.delete.side_effect = Exception("Hata")
        reg.get.return_value = mock_repo
        result = svc.sil("1")
        assert result.basarili is False
