TABLES = {

    # ─────────────── PERSONEL VT ───────────────

    "Personel": {
        "pk": "KimlikNo",
        "columns": [
            "KimlikNo","AdSoyad","DogumYeri","DogumTarihi","HizmetSinifi",
            "KadroUnvani","GorevYeri","KurumSicilNo","MemuriyeteBaslamaTarihi",
            "CepTelefonu","Eposta","MezunOlunanOkul","MezunOlunanFakulte",
            "MezuniyetTarihi","DiplomaNo","MezunOlunanOkul2",
            "MezunOlunanFakulte2","MezuniyetTarihi2","DiplomaNo2",
            "Resim","Diploma1","Diploma2","OzlukDosyasi","Durum",
            "AyrilisTarihi","AyrilmaNedeni","MuayeneTarihi","Sonuc"
        ],
        "date_fields": [
            "DogumTarihi",
            "MemuriyeteBaslamaTarihi",
            "MezuniyetTarihi",
            "MezuniyetTarihi2",
            "AyrilisTarihi",
            "MuayeneTarihi",
        ],
    },

    "Izin_Giris": {
        "pk": "Izinid",
        "columns": [
            "Izinid","HizmetSinifi","Personelid","AdSoyad",
            "IzinTipi","BaslamaTarihi","Gun","BitisTarihi","Durum"
        ],
        "date_fields": ["BaslamaTarihi", "BitisTarihi"],
    },

    "Izin_Bilgi": {
        "pk": "TCKimlik",
        "columns": [
            "TCKimlik","AdSoyad","YillikDevir","YillikHakedis",
            "YillikToplamHak","YillikKullanilan","YillikKalan",
            "SuaKullanilabilirHak","SuaKullanilan","SuaKalan",
            "SuaCariYilKazanim","RaporMazeretTop"
        ]
    },

    "FHSZ_Puantaj": {
        "pk": ["Personelid", "AitYil", "Donem"],   # composite PK
        "columns": [
            "Personelid","AdSoyad","Birim","CalismaKosulu",
            "AitYil","Donem","AylikGun","KullanilanIzin",
            "FiiliCalismaSaat"
        ]
    },

    # ─────────────── CİHAZ VT ───────────────

    "Cihazlar": {
        "pk": "Cihazid",
        "columns": [                          # ← "colums" → "columns"
            "Cihazid","CihazTipi","Marka","Model","Amac",
            "Kaynak","SeriNo","NDKSeriNo","HizmeteGirisTarihi",
            "RKS","Sorumlusu","Gorevi","NDKLisansNo","BaslamaTarihi",
            "BitisTarihi","LisansDurum","AnaBilimDali","Birim","BulunduguBina",
            "GarantiDurumu","GarantiBitisTarihi","DemirbasNo","KalibrasyonGereklimi",
            "BakimDurum","Durum","Img","NDKLisansBelgesi"
        ],
        "date_fields": [
            "HizmeteGirisTarihi",
            "BaslamaTarihi",
            "BitisTarihi",
            "GarantiBitisTarihi",
        ],
    },

    "Cihaz_Teknik": {
        "pk": "Cihazid",
        "sync": False,  # Local-only table (Google Sheets'e eklenmedi)
        "columns": [
            "Cihazid",
            "BirincilUrunNumarasi",
            "MarkaAdi",
            "EtiketAdi",
            "UrunTanimi",
            "VersiyonModel",
            "KatalogNo",
            "TemelUdiDi",
            "Aciklama",
            "KurumUnvan",
            "KurumGorunenAd",
            "KurumNo",
            "KurumTelefon",
            "KurumEposta",
            "Durum",
            "UtsBaslangicTarihi",
            "KontroleGonderildigiTarih",
            "CihazKayitTipi",
            "UrunTipi",
            "Sinif",
            "IthalImalBilgisi",
            "GmdnTerimKod",
            "GmdnTerimTurkceAd",
            "GmdnTerimTurkceAciklama",
            "KalibrasyonaTabiMi",
            "KalibrasyonPeriyodu",
            "BakimaTabiMi",
            "BakimPeriyodu",
            "IyonizeRadyasyonIcerir",
            "SinirliKullanimSayisiVar",
            "SinirliKullanimSayisi",
            "TekHastayaKullanilabilir",
            "MrgUyumlu",
            "SutEslesmesiSet",
            "BaskaImalatciyaUrettirildiMi",
            "MenseiUlkeSet",
            "IthalEdilenUlkeSet"
        ],
        "date_fields": [
            "UtsBaslangicTarihi",
            "KontroleGonderildigiTarih",
        ],
    },

    "Cihaz_Belgeler": {
        "pk": ["Cihazid", "BelgeTuru", "Belge"],
        "sync": False,  # Local-only table (Google Sheets'e eklenmedi)
        "columns": [
            "Cihazid",              # Cihaz ID
            "BelgeTuru",            # Belge türü (Teknik, Arıza, Bakım, Kalibrasyon, vb)
            "Belge",                # Dosya adı
            "BelgeAciklama",        # Açıklama
            "YuklenmeTarihi",       # Upload tarihi
            "IliskiliBelgeID",      # Foreign Key (Arizaid, Planid, Kalid, vb)
            "IliskiliBelgeTipi",    # "Ariza" / "Bakim" / "Kalibrasyon" / NULL
        ],
        "date_fields": ["YuklenmeTarihi"],
    },

    "Dokumanlar": {
        "pk": ["EntityType", "EntityId", "BelgeTuru", "Belge"],
        # sync=True: tüm metadata makineler arası Sheets üzerinden senkronize edilir.
        # LocalPath makineye özgü yolu saklar (diğer makinede geçersiz olabilir ama
        # DrivePath öncelikli açılır, LocalPath yedek olarak korunur).
        # ÖNEMLİ: Google Sheets'te "Dokumanlar" sayfasının oluşturulmuş olması gerekir.
        "sync": True,
        "columns": [
            "EntityType",
            "EntityId",
            "BelgeTuru",
            "Belge",
            "DocType",
            "DisplayName",
            "LocalPath",
            "BelgeAciklama",
            "YuklenmeTarihi",
            "DrivePath",
            "IliskiliBelgeID",
            "IliskiliBelgeTipi",
        ],
        "date_fields": ["YuklenmeTarihi"],
    },

    "Cihaz_Teknik_Belge": {
        "pk": ["Cihazid", "BelgeTuru", "Belge"],
        "sync": False,  # Local-only table (Google Sheets'e eklenmedi)
        "columns": [
            "Cihazid",
            "BelgeTuru",
            "Belge",
            "BelgeAciklama",
        ],
        "date_fields": [],
    },

    "Cihaz_Ariza": {
        "pk": "Arizaid",
        "columns": [                          # ← "colums" → "columns"
            "Arizaid","Cihazid","BaslangicTarihi","Saat","Bildiren",
            "ArizaTipi","Oncelik","Baslik",   # ← "Baslık" encoding düzeltildi
            "ArizaAcikla","Durum","Rapor"
        ],
        "date_fields": ["BaslangicTarihi"],
    },

    "Ariza_Islem": {
        "pk": "Islemid",
        "columns": [                          # ← "colums" → "columns"
            "Islemid","Arizaid","Tarih","Saat","IslemYapan",
            "IslemTuru","YapilanIslem","YeniDurum","Rapor"
        ],
        "date_fields": ["Tarih"],
    },

    "Periyodik_Bakim": {
        "pk": "Planid",
        "columns": [                          # ← "colums" → "columns"
            "Planid","Cihazid","BakimPeriyodu","BakimSirasi","PlanlananTarih",
            "Bakim","Durum","BakimTarihi","BakimTipi","YapilanIslemler","Aciklama",
            "Teknisyen","Rapor"
        ],
        "date_fields": ["PlanlananTarih", "BakimTarihi"],
    },

    "Kalibrasyon": {
        "pk": "Kalid",
        "columns": [                          # ← "colums" → "columns"
            "Kalid","Cihazid",                # ← "cihazid" → "Cihazid" (migrations.py ile eşleşti)
            "Firma","SertifikaNo","YapilanTarih",
            "Gecerlilik","BitisTarihi","Durum","Dosya","Aciklama"
        ],
        "date_fields": ["YapilanTarih", "BitisTarihi"],
    },

    # ─────────────── SABİT VT ───────────────

    "Sabitler": {
        "pk": "Rowid",
        "sync_mode": "pull_only",  # Read-only table
        "columns": [
            "Rowid","Kod","MenuEleman","Aciklama"
        ],
    },

    "Tatiller": {
        "pk": "Tarih",
        "sync_mode": "pull_only",  # Read-only table
        "columns": [
            "Tarih","ResmiTatil"
        ],
        "date_fields": ["Tarih"],
        
    },

    "Loglar": {
        "pk": None,                           # ← "Personelid" kaldırıldı (Loglar'da PK yok)
        "columns": [
            "Tarih","Saat","Kullanici","Modul","Islem","Detay"
        ],
        "date_fields": ["Tarih"],
        "sync": False                         # Log tablosu sync dışı
    },

    # ─────────────── RKE VT ───────────────

    "RKE_List": {
        "pk": "EkipmanNo",                      # migrations.py ile uyumlu PK
        "columns": [
            "EkipmanNo","KoruyucuNumarasi","AnaBilimDali","Birim",
            "KoruyucuCinsi","KursunEsdegeri","HizmetYili","Bedeni","KontrolTarihi",
            "Durum","Aciklama",               # ← encoding düzeltildi
            "VarsaDemirbasNo",                # ← encoding düzeltildi
            "KayitTarih","Barkod"
        ],
        "date_fields": ["KontrolTarihi"],
    },

    "RKE_Muayene": {
        "pk": "KayitNo",                      # ← "Personelid" → "KayitNo" (migrations.py ile eşleşti)
        "columns": [
            "KayitNo","EkipmanNo","FMuayeneTarihi","FizikselDurum","SMuayeneTarihi",
            "SkopiDurum","Aciklamalar",
            "KontrolEdenUnvani",              # ← "/" kaldırıldı (SQLite kolon adında slash olmaz)
            "BirimSorumlusuUnvani",           # ← "/" kaldırıldı
            "Notlar",                         # ← "Not" → "Notlar" (migrations.py ile eşleşti)
            "Rapor"
        ],
        "date_fields": ["FMuayeneTarihi", "SMuayeneTarihi"],
    },

    "Personel_Saglik_Takip": {
        "pk": "KayitNo",
        "columns": [
            "KayitNo", "Personelid", "AdSoyad", "Birim", "Yil",
            "MuayeneTarihi", "SonrakiKontrolTarihi", "Sonuc", "Durum",
            "RaporDosya", "Notlar",
            "DermatolojiMuayeneTarihi", "DermatolojiDurum", 
            "DahiliyeMuayeneTarihi", "DahiliyeDurum",
            "GozMuayeneTarihi", "GozDurum",
            "GoruntulemeMuayeneTarihi", "GoruntulemeDurum",
        ],
        "date_fields": [
            "MuayeneTarihi", "SonrakiKontrolTarihi",
            "DermatolojiMuayeneTarihi", "DahiliyeMuayeneTarihi",
            "GozMuayeneTarihi", "GoruntulemeMuayeneTarihi"
        ],
    }

}
