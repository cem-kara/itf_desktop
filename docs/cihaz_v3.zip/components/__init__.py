# -*- coding: utf-8 -*-
"""
Cihaz modülü gömülebilir bileşenler.
Her bileşen CihazMerkezPage sekmelerinde kullanılır.
"""
