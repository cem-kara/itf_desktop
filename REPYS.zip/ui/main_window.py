
from datetime import datetime

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QStackedWidget, QLabel, QStatusBar
)
from PySide6.QtCore import Qt, QTimer, Slot
from PySide6.QtGui import QCloseEvent

from core.config import AppConfig
from core.logger import logger, log_ui_error
from core.paths import DB_PATH
from ui.sidebar import Sidebar
from ui.guards import ActionGuard, PageGuard
from ui.pages.placeholder import WelcomePage, PlaceholderPage 
from ui.pages.imports.import_center import ImportCenterPage
from ui.styles.colors import DarkTheme
from database.sync_worker import SyncWorker
from database.sqlite_manager import SQLiteManager
from ui.dialogs.about_dialog import HakkindaDialog



class MainWindow(QMainWindow):

    def __init__(self, db=None, authorization_service=None, session_context=None):
        super().__init__()

        self.setWindowTitle(f"{AppConfig.APP_NAME} v{AppConfig.VERSION}")
        self.setMinimumSize(1100, 700)
        self.resize(1280, 800)

        self._pages = {}
        self._sync_worker = None
        self._bildirim_worker = None
        self._db = db or SQLiteManager()
        self._authorization_service = authorization_service
        self._session_context = session_context
        self._sabitler_cache = None  # Sabitler tablosu cache (performans için)
        self._build_ui()
        self._build_status_bar()
        self._setup_sync()
        self._setup_bildirim()
        self._load_sabitler_cache()  # Uygulama başladığında bir kere yükle
        self._setup_theme_listener()  # Tema değişikliğini dinle

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)

        root_layout = QVBoxLayout(central)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        # ── Ana alan (sidebar + içerik) ───────────────────────────
        body = QWidget()
        body.setProperty("bg-role", "page")
        main_layout = QHBoxLayout(body)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Sidebar (permission filter)
        self._page_guard = None
        self._action_guard = None
        if self._authorization_service and self._session_context:
            self._page_guard = PageGuard(self._authorization_service, self._session_context)
            self._action_guard = ActionGuard(self._authorization_service, self._session_context)
        self.sidebar = Sidebar(page_guard=self._page_guard)
        self.sidebar.menu_clicked.connect(self._on_menu_clicked)
        # self.sidebar.dashboard_clicked.connect(self._open_dashboard)  # TODO: Dashboard sayfası geliştirilirken aktif olacak
        self.sidebar.sync_btn.clicked.connect(self._start_sync)
        main_layout.addWidget(self.sidebar)

        # İçerik alanı
        content = QWidget()
        content.setObjectName("content_area")
        content.setProperty("bg-role", "page")
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)

        # Bildirim paneli
        from ui.components.bildirim_paneli import BildirimPaneli
        self.bildirim_paneli = BildirimPaneli()
        self.bildirim_paneli.sayfa_ac.connect(self._on_menu_clicked)
        content_layout.addWidget(self.bildirim_paneli)

        # Stacked Widget
        self.stack = QStackedWidget()
        content_layout.addWidget(self.stack, 1)

        main_layout.addWidget(content, 1)
        root_layout.addWidget(body, 1)

        # Dummy page_title (geriye dönük uyumluluk - artık kullanılmıyor)
        class DummyLabel:
            def setText(self, *args): pass
            def setVisible(self, *args): pass
        self.page_title = DummyLabel()

        # Hoş geldin
        from ui.pages.placeholder import WelcomePage
        self._welcome = WelcomePage(self.stack)
        self.stack.addWidget(self._welcome)
        self.stack.setCurrentWidget(self._welcome)

    def _build_status_bar(self):
        self.status = QStatusBar()
        self.status.setProperty("bg-role", "panel")
        self.status.setProperty("border-role", "primary")
        self.setStatusBar(self.status)

        self.sync_status_label = QLabel("Hazır")
        self.sync_status_label.setProperty("color-role", "ok")
        self.status.addWidget(self.sync_status_label)

        self.last_sync_label = QLabel("")
        self.status.addWidget(self.last_sync_label, 1)

        version_label = QLabel(
            f'<a href="#" style="color:{"muted"}; '
            f'text-decoration:none;">v{AppConfig.VERSION}</a>'
        )
        version_label.setToolTip("Hakkında — lisans bilgileri için tıklayın")
        version_label.setCursor(Qt.CursorShape.PointingHandCursor)
        version_label.linkActivated.connect(self._show_hakkinda)
        self.status.addPermanentWidget(version_label)

    @Slot()
    def _show_hakkinda(self, *_):
        """Hakkında dialogunu aç."""
        dlg = HakkindaDialog(self)
        dlg.exec()

    # ── SAYFA YÖNETİMİ ──

    # @Slot()
    # def _open_dashboard(self):
    #     self._on_menu_clicked("YÖNETİCİ İŞLEMLERİ", "Genel Bakış")

    def _on_menu_clicked(self, group, baslik, *args):
        """
        Menüden veya dashboard'dan gelen tıklamaları yönetir.
        Dashboard'dan gelirse `args` içinde filtre dict'i bulunur.
        """
        filters = args[0] if args else {}
        logger.info(f"Menü seçildi: {group} → {baslik} (Filtreler: {filters})")

        # Yetki kontrolü (IP-05: Sayfa Guard)
        if self._page_guard:
            from ui.permissions.page_permissions import PAGE_PERMISSIONS
            perm_key = PAGE_PERMISSIONS.get(baslik)
            if perm_key and not self._page_guard.can_open(perm_key):
                from PySide6.QtWidgets import QMessageBox
                QMessageBox.warning(
                    self,
                    "Yetki Hatası",
                    f"'{baslik}' sayfasına erişim yetkiniz bulunmamaktadır.\n\n"
                    f"Gerekli yetki: {perm_key}"
                )
                logger.warning(f"Yetkisiz sayfa erişim denemesi: {baslik} (yetki: {perm_key})")
                return

        try:
            if baslik in self._pages:
                page = self._pages[baslik]
            else:
                page = self._create_page(group, baslik)
                if isinstance(page, PlaceholderPage) or page is None:
                    if page:
                        self.stack.addWidget(page)
                        self.stack.setCurrentWidget(page)
                    return
                self._pages[baslik] = page
                self.stack.addWidget(page)

            self.stack.setCurrentWidget(page)
            self.page_title.setText(baslik)
            self.page_title.setVisible(True)

            if filters and hasattr(page, "apply_filters"):
                logger.info(f"'{baslik}' sayfasına filtreler uygulanıyor: {filters}")
                page.apply_filters(filters)  # type: ignore[attr-defined]
        except Exception as e:
            log_ui_error("menu_click", e, group=group, page=baslik)
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.critical(
                self,
                "Sayfa Acma Hatasi",
                f"'{baslik}' sayfasi acilirken bir hata olustu.\n"
                f"Detaylar ui_log.log dosyasina yazildi.\n\n{type(e).__name__}: {e}"
            )

    def _create_page(self, group, baslik):
        # if baslik == "Genel Bakış":
        #     from ui.pages.dashboard import DashboardPage
        #     page = DashboardPage(db=self._db)
        #     page.open_page_requested.connect(self._on_menu_clicked)
        #     page.btn_kapat.clicked.connect(lambda: self._close_page("Genel Bakış"))
        #     page.load_data()
        #     return page
        if baslik == "İmportlar":
            page = ImportCenterPage(db=self._db)
            return page

        if baslik == "Personel Listesi":
            from ui.pages.personel.personel_listesi import PersonelListesiPage
            page = PersonelListesiPage(db=self._db, action_guard=self._action_guard)
            page.table.doubleClicked.connect(
                lambda idx: self._open_personel_detay(page, idx)
            )
            page.detay_requested.connect(self._open_personel_merkez)
            page.izin_requested.connect(lambda data: self.open_izin_giris(data))
            page.btn_yeni.clicked.connect(lambda: self._on_menu_clicked("Personel", "Personel Ekle"))
            # Kapat butonu signal'ini bağla
            page.close_requested.connect(lambda: self._close_page("Personel Listesi"))
            page.load_data()
            return page

        if baslik == "Personel Ekle":
            from ui.pages.personel.personel_ekle import PersonelEklePage
            page = PersonelEklePage(
                db=self._db,
                on_saved=self._on_personel_saved,
                action_guard=self._action_guard
            )
            # Form kapandığında (iptal/kaydet) personel listesine dön
            page.form_closed.connect(self._on_personel_saved)
            return page

        if baslik in ("İzin Takip ve FHSZ Yönetim"):
            # Üç sayfayı birleştirilmiş merkez olarak göster
            from ui.pages.personel.izin_fhsz_puantaj_merkez import IzinFHSZPuantajMerkezPage
            page = IzinFHSZPuantajMerkezPage(db=self._db)
            page.kapat_istegi.connect(lambda: self._close_page("İzin Takip ve FHSZ Yönetim"))
            return page
        
        if baslik in ("Diğer Rad. Gör. FHSZ Yön."):
            # Üç sayfayı birleştirilmiş merkez olarak göster
            from ui.pages.fhsz.dis_alan_merkez_page import DisAlanMerkezPage
            page = DisAlanMerkezPage(db=self._db)
            page.kapat_istegi.connect(lambda: self._close_page("Diğer Rad. Gör. FHSZ Yön."))
            return page

        if baslik == "Sağlık Takip":
            from ui.pages.personel.saglik_takip import SaglikTakipPage
            page = SaglikTakipPage(db=self._db)
            page.btn_kapat.clicked.connect(lambda: self._close_page("Sağlık Takip"))
            page.load_data()
            return page

        if baslik == "Dozimetre Takip":
            from ui.pages.personel.dozimetre_takip import DozimetreTakipPage
            # Pass DB file path (str) to satisfy page's expected type
            db_path = getattr(self._db, "db_path", "")
            page = DozimetreTakipPage(db=db_path)
            #{page.btn_kapat.clicked.connect(lambda: self._close_page("Dozimetre Takip"))
            fn = getattr(page, "load_data", None)
            if callable(fn):
                fn()
            return page
        

        if baslik == "Cihaz Ekle":
            from ui.pages.cihaz.cihaz_ekle import CihazEklePage
            page = CihazEklePage(
                db=self._db,
                on_saved=self._on_cihaz_saved,
                action_guard=self._action_guard
            )
            return page


        if baslik == "Cihaz Listesi":
            from ui.pages.cihaz.cihaz_listesi import CihazListesiPage
            page = CihazListesiPage(db=self._db, action_guard=self._action_guard)
            page.add_requested.connect(lambda: self._on_menu_clicked("Cihaz", "Cihaz Ekle"))
            page.detay_requested.connect(self._open_cihaz_merkez)
            page.edit_requested.connect(self._open_cihaz_merkez)
            page.periodic_maintenance_requested.connect(self.open_periodic_maintenance_for_device)
            page.load_data()
            return page

        if baslik == "Teknik Hizmetler":
            from ui.pages.cihaz.teknik_hizmetler import TeknikHizmetlerPage
            page = TeknikHizmetlerPage(db=self._db, action_guard=self._action_guard)
            return page
        
        if baslik in ("RKE Envanter", "RKE Muayene", "RKE Raporlama"):
            from ui.pages.rke.rke_merkez import RKEMerkezPage
            page = RKEMerkezPage(db=self._db, action_guard=self._action_guard)
            # İlk açılışta istenen sekmeye git
            if baslik == "RKE Muayene":
                page._switch_tab("MUAYENE")
            elif baslik == "RKE Raporlama":
                page._switch_tab("RAPOR")
            return page

        if baslik == "Admin Panel":
            from ui.admin.admin_panel import AdminPanel
            page = AdminPanel(db=self._db, action_guard=self._action_guard)
            page.btn_kapat.clicked.connect(lambda: self._close_page("Admin Panel"))
            return page

        if baslik == "Doküman Yönetimi":
            from ui.pages.dokuman.dokuman_listesi import DokumanListesiPage
            page = DokumanListesiPage(db=self._db)
            #{page.btn_kapat.clicked.connect(lambda: self._close_page("Doküman Yönetimi"))
            return page
        
        if baslik == "Ayarlar":
            from ui.admin.settings_page import SettingsPage
            page = SettingsPage(db=self._db)
            return page

        # ── NÖBET ────────────────────────────────────────────────────
        if baslik == "Birim & Vardiyalar":
            from ui.pages.nobet.nobet_vardiya_page import NobetVardiyaPage
            return NobetVardiyaPage(db=self._db, action_guard=self._action_guard)

        if baslik == "Nöbet Planı":
            from ui.pages.nobet.nobet_merkez_page import NobetMerkezPage
            return NobetMerkezPage(db=self._db, action_guard=self._action_guard)

        if baslik == "Personel Özeti":
            from ui.pages.nobet.nobet_ozet_page import NobetOzetPage
            return NobetOzetPage(db=self._db, action_guard=self._action_guard)

        if baslik == "Raporlar":
            from ui.pages.nobet.nobet_rapor_page import NobetRaporPage
            return NobetRaporPage(db=self._db, action_guard=self._action_guard)

        return PlaceholderPage(
            title=baslik,
            subtitle=f"{group} modülü — geliştirme aşamasında"
        )

    def _open_personel_detay(self, liste_page, index):
        """Personel listesinde çift tıklama → Personel Merkez (360) sayfası aç."""
        source_idx = liste_page._proxy.mapToSource(index)
        row_data = liste_page._model.get_row(source_idx.row())
        if not row_data:
            return

        tc = row_data.get("KimlikNo", "")
        ad = row_data.get("AdSoyad", "")
        merkez_key = f"__merkez_{tc}"

        # Eski sayfa varsa kaldır
        if merkez_key in self._pages:
            old = self._pages.pop(merkez_key)
            self.stack.removeWidget(old)
            old.deleteLater()

        from ui.pages.personel.personel_merkez import PersonelMerkezPage
        page = PersonelMerkezPage(
            db=self._db,
            personel_id=tc,
            sabitler_cache=self._sabitler_cache
        )
        
        # Kapatma sinyali listeye dönüşü tetikler
        page.kapat_istegi.connect(lambda: self._back_to_personel_listesi(merkez_key))
        
        self._pages[merkez_key] = page
        self.stack.addWidget(page)
        self.stack.setCurrentWidget(page)
        self.page_title.setText(f"Personel Kartı — {ad}")

    def _back_to_personel_listesi(self, detay_key):
        """Detay sayfasından listeye geri dön."""
        if "Personel Listesi" in self._pages:
            page = self._pages["Personel Listesi"]
            page.load_data()
            self.stack.setCurrentWidget(page)
            self.page_title.setText("Personel Listesi")
            self.sidebar.set_active("Personel Listesi")

        if detay_key in self._pages:
            old = self._pages.pop(detay_key)
            self.stack.removeWidget(old)
            old.deleteLater()

    def _open_personel_merkez(self, row_data):
        """Personel detay butonuna tıklama → Personel Merkez (360) sayfası aç."""
        if not row_data:
            return

        tc = row_data.get("KimlikNo", "")
        ad = row_data.get("AdSoyad", "")
        merkez_key = f"__merkez_{tc}"

        # Eski sayfa varsa kaldır
        if merkez_key in self._pages:
            old = self._pages.pop(merkez_key)
            self.stack.removeWidget(old)
            old.deleteLater()

        from ui.pages.personel.personel_merkez import PersonelMerkezPage
        page = PersonelMerkezPage(
            db=self._db,
            personel_id=tc,
            sabitler_cache=self._sabitler_cache
        )
        
        # Kapatma sinyali listeye dönüşü tetikler
        page.kapat_istegi.connect(lambda: self._back_to_personel_listesi(merkez_key))
        
        self._pages[merkez_key] = page
        self.stack.addWidget(page)
        self.stack.setCurrentWidget(page)
        self.page_title.setText(f"Personel Kartı — {ad}")

    def open_isten_ayrilik(self, personel_data, from_key=None):
        """İşten ayrılık sayfasını aç."""
        tc = personel_data.get("KimlikNo", "")
        ad = personel_data.get("AdSoyad", "")
        ayrilik_key = f"__ayrilik_{tc}"

        if ayrilik_key in self._pages:
            old = self._pages.pop(ayrilik_key)
            self.stack.removeWidget(old)
            old.deleteLater()

        from ui.pages.personel.isten_ayrilik import IstenAyrilikPage
        page = IstenAyrilikPage(
            db=self._db,
            personel_data=personel_data,
            on_back=lambda: self._back_from_ayrilik(ayrilik_key, from_key)
        )
        self._pages[ayrilik_key] = page
        self.stack.addWidget(page)
        self.stack.setCurrentWidget(page)
        self.page_title.setText(f"İşten Ayrılış — {ad}")

    def _back_from_ayrilik(self, ayrilik_key, from_key=None):
        """Ayrılık sayfasından geri dön."""
        if from_key and from_key in self._pages:
            self.stack.setCurrentWidget(self._pages[from_key])
        elif "Personel Listesi" in self._pages:
            page = self._pages["Personel Listesi"]
            page.load_data()
            self.stack.setCurrentWidget(page)
            self.page_title.setText("Personel Listesi")
            self.sidebar.set_active("Personel Listesi")

        if ayrilik_key in self._pages:
            old = self._pages.pop(ayrilik_key)
            self.stack.removeWidget(old)
            old.deleteLater()

    def open_izin_giris(self, personel_data, from_key=None):
        """İzin giriş dialogunu aç."""
        try:
            from ui.pages.personel.components.hizli_izin_giris import HizliIzinGirisDialog

            dialog = HizliIzinGirisDialog(self._db, personel_data or {}, parent=self)
            dialog.exec()

            # Kayıt sonrası liste görünümü güncel kalsın.
            if "Personel Listesi" in self._pages:
                page = self._pages["Personel Listesi"]
                if hasattr(page, "load_data"):
                    page.load_data()

            if from_key and from_key in self._pages:
                self.stack.setCurrentWidget(self._pages[from_key])

        except Exception as e:
            log_ui_error("open_izin_giris", e)
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.critical(
                self,
                "İzin Girişi Hatası",
                f"İzin girişi ekranı açılırken bir hata oluştu.\n\n{type(e).__name__}: {e}",
            )

    def _back_from_izin(self, izin_key, from_key=None):
        """İzin sayfasından geri dön."""
        # Geldiği sayfaya geri dön
        if from_key and from_key in self._pages:
            page = self._pages[from_key]
            self.stack.setCurrentWidget(page)
            ad = from_key.replace("__detay_", "")
            self.page_title.setText(f"Personel Detay — {ad}")
        elif "Personel Listesi" in self._pages:
            page = self._pages["Personel Listesi"]
            page.load_data()
            self.stack.setCurrentWidget(page)
            self.page_title.setText("Personel Listesi")
            self.sidebar.set_active("Personel Listesi")

        if izin_key in self._pages:
            old = self._pages.pop(izin_key)
            self.stack.removeWidget(old)
            old.deleteLater()

    def register_page(self, baslik, widget):
        self._pages[baslik] = widget
        self.stack.addWidget(widget)

    def _close_page(self, baslik):
        """Sayfayı kapat ve welcome'a dön."""
        if baslik in self._pages:
            old = self._pages.pop(baslik)
            self.stack.removeWidget(old)
            # closeEvent'i çağırarak threads'i temizleyelim
            if hasattr(old, 'closeEvent'):
                old.closeEvent(QCloseEvent())
            old.deleteLater()
        self.stack.setCurrentWidget(self._welcome)
        self.page_title.setVisible(False)
        self.sidebar.set_active("")

    # ── BİLDİRİM ──

    def _setup_bildirim(self):
        """Uygulama açılışından 5 sn sonra ilk bildirim kontrolünü başlatır."""
        QTimer.singleShot(5000, self._tetikle_bildirim)

    def _load_sabitler_cache(self):
        """Sabitler tablosunu cache'e yükler (performans için bir kere)."""
        try:
            from core.di import get_cihaz_service as _cs
            self._sabitler_cache = _cs(self._db).get_sabitler().veri or []
            logger.info(f"Sabitler cache yüklendi: {len(self._sabitler_cache)} kayıt")
        except Exception as e:
            logger.error(f"Sabitler cache yükleme hatası: {e}")
            self._sabitler_cache = []

    def _tetikle_bildirim(self):
        """BildirimWorker'ı başlatır; zaten çalışıyorsa atlar."""
        if self._bildirim_worker and self._bildirim_worker.isRunning():
            return
        from core.bildirim_servisi import BildirimWorker
        db_path = getattr(self._db, "db_path", DB_PATH)
        self._bildirim_worker = BildirimWorker(db_path)
        self._bildirim_worker.sonuc_hazir.connect(self.bildirim_paneli.guncelle)
        self._bildirim_worker.start()
        logger.info("Bildirim kontrolü başlatıldı")

    # ── SENKRONİZASYON ──

    def _setup_sync(self):
        if not AppConfig.is_online_mode():
            self.sidebar.sync_btn.setEnabled(False)
            self.sidebar.sync_btn.setText("  Offline Mod")
            self.sidebar.set_sync_status("Offline mod", "warn")
            self._set_sync_status_label("Offline mod", "warn")
            return
        if AppConfig.get_auto_sync():
            QTimer.singleShot(3000, self._start_sync)
            self._sync_timer = QTimer(self)
            self._sync_timer.timeout.connect(self._start_sync)
            self._sync_timer.start(AppConfig.SYNC_INTERVAL_MIN * 60 * 1000)

    def _start_sync(self):
        if not AppConfig.is_online_mode():
            logger.info("Sync atlandi: uygulama offline modda")
            return
        if self._sync_worker and self._sync_worker.isRunning():
            logger.warning("Sync zaten çalışıyor, yeni sync atlanıyor")
            return
        
        logger.info("Sync başlatılıyor...")
        self.sidebar.set_sync_enabled(False)
        self.sidebar.set_sync_status("Senkronize ediliyor...", "warn")
        self._set_sync_status_label("Senkronize ediliyor...", "warn")

        self._sync_worker = SyncWorker()
        self._sync_worker.finished.connect(self._on_sync_finished)
        self._sync_worker.error.connect(self._on_sync_error)
        self._sync_worker.start()

    @Slot()
    def _on_sync_finished(self):
        now = datetime.now().strftime("%H:%M:%S")
        logger.info(f"Sync başarıyla tamamlandı ({now})")
        
        self.sidebar.set_sync_enabled(True)
        self.sidebar.set_sync_status("Senkronize", self.STATUS_READY_COLOR)
        self._set_sync_status_label("Senkronize", self.STATUS_READY_COLOR)
        self.last_sync_label.setText(f"Son sync: {now}")
        self._refresh_active_page()
        # Dashboard açıksa onu da yenile
        # if "Genel Bakış" in self._pages:
        #     dashboard_page = self._pages["Genel Bakış"]
        #     if hasattr(dashboard_page, "load_data"):
        #         logger.info("Dashboard yenileniyor...")
        #         dashboard_page.load_data()
        # Sync sonrası bildirimleri de güncelle
        self._tetikle_bildirim()

    @Slot(str, str)
    def _on_sync_error(self, short_msg, detail_msg):
        """
        Sync hatası geldiğinde detaylı bilgi göster
        
        Args:
            short_msg: Kısa hata mesajı (status bar için)
            detail_msg: Detaylı hata mesajı (tooltip/log için)
        """
        now = datetime.now().strftime("%H:%M:%S")
        
        logger.error(f"Sync hatası: {short_msg} - {detail_msg}")
        
        # UI güncelleme
        self.sidebar.set_sync_enabled(True)
        self.sidebar.set_sync_status(short_msg, self.STATUS_ERROR_COLOR)
        
        # Status bar'da kısa mesaj
        self._set_sync_status_label(short_msg, self.STATUS_ERROR_COLOR)
        
        # Detaylı mesajı tooltip olarak ekle
        self.sync_status_label.setToolTip(
            f"Hata Zamanı: {now}\n"
            f"Kısa Açıklama: {short_msg}\n"
            f"Detay: {detail_msg}\n\n"
            f"Daha fazla bilgi için log dosyalarını kontrol edin."
        )
        
        self.last_sync_label.setText(f"Hata: {now}")
        self.last_sync_label.setToolTip(detail_msg)
        
        # Opsiyonel: Kullanıcıya bildirim göster
        from PySide6.QtWidgets import QMessageBox
        msg_box = QMessageBox(self)
        msg_box.setIcon(QMessageBox.Icon.Warning)
        msg_box.setWindowTitle("Senkronizasyon Hatası")

        # API 503 (Servis Ulaşılamıyor) hatası için özel mesaj
        is_service_unavailable = "503" in detail_msg or "unavailable" in detail_msg.lower()

        if is_service_unavailable:
            service_error_short = "Google Servisi Ulaşılamıyor"
            service_error_info = (
                "Google Sheets servisi şu anda geçici olarak yanıt vermiyor. "
                "Bu genellikle Google tarafındaki kısa süreli bir sorundur.\n\n"
                "Lütfen birkaç dakika bekleyip tekrar deneyin. Uygulama, bir sonraki "
                "otomatik senkronizasyonda veya manuel yenilemede tekrar deneyecektir."
            )
            msg_box.setText(service_error_short)
            msg_box.setInformativeText(service_error_info)
            msg_box.setDetailedText(f"Hata Detayı:\n{detail_msg}")
            
            # UI'da da daha anlaşılır bir mesaj göster
            self.sidebar.set_sync_status(service_error_short, self.STATUS_ERROR_COLOR)
            self._set_sync_status_label(service_error_short, self.STATUS_ERROR_COLOR)
        else:
            msg_box.setText(short_msg)
            msg_box.setInformativeText(detail_msg)
            msg_box.setDetailedText(
                f"Hata zamanı: {now}\n\n"
                f"Çözüm önerileri:\n"
                f"1. İnternet bağlantınızı kontrol edin.\n"
                f"2. Google Sheets erişim izinlerini kontrol edin.\n"
                f"3. Birkaç dakika bekleyip tekrar deneyin.\n"
                f"4. Sorun devam ederse log dosyalarını kontrol edin:\n"
                f"   - logs/app.log\n"
                f"   - logs/sync.log\n"
                f"   - logs/errors.log"
            )

        msg_box.setStandardButtons(QMessageBox.StandardButton.Ok)
        msg_box.exec()

    def closeEvent(self, event):
        # Eğer sync çalışıyorsa kullanıcıyı bilgilendir ve animasyonlu modal göster
        if self._sync_worker and self._sync_worker.isRunning():
            from ui.components.shutdown_sync_dialog import ShutdownSyncDialog

            dlg = ShutdownSyncDialog(self, sync_worker=self._sync_worker)
            # exec() bloklayıcıdır ama worker başka thread'de çalıştığı için uygulama donmaz;
            # dialog worker'ın `finished` veya `error` sinyali ile kapanacaktır.
            dlg.exec()

            # Dialog kapandığında sync durduysa devam et, yoksa yine stop() çağır
            if self._sync_worker and self._sync_worker.isRunning():
                try:
                    self._sync_worker.stop()
                except Exception:
                    pass

        if self._bildirim_worker and self._bildirim_worker.isRunning():
            self._bildirim_worker.quit()
            self._bildirim_worker.wait(1000)
        if self._db:
            self._db.close()
        event.accept()

    def _refresh_active_page(self):
        current = self.stack.currentWidget()
        if hasattr(current, "load_data"):
            try:
                current.load_data()  # type: ignore[attr-defined]
            except Exception as e:
                logger.error(f"Sayfa yenileme hatası: {e}")

    def _set_sync_status_label(self, text: str, color: str):
        """Sync status label metnini ve rengini ayarla (property tabanlı)."""
        self.sync_status_label.setText(text)
        # Dinamik renk için property tabanlı yaklaşım yerine,
        # özel durum olarak inline stil kabul edilebilir (MainWindow özel widget)
        self.sync_status_label.setStyleSheet("color: {};".format(color))
        # Not: Alternatif olarak color-role property kullanılabilir ama
        # bu durumda sınırlı sayıda önceden tanımlı rol olmalı (success/error/warning).
        # Dinamik hex renk gerektiren durumlar için inline stil uygun.

    def _on_personel_saved(self):
        """Personel kaydedildikten sonra listeye dön ve yenile."""
        if "Personel Listesi" in self._pages:
            # Personel Listesi cache'de varsa oraya dön
            page = self._pages["Personel Listesi"]
            page.load_data()
            self.stack.setCurrentWidget(page)
            self.page_title.setText("Personel Listesi")
            self.sidebar.set_active("Personel Listesi")
        else:
            # Personel Listesi yoksa welcome sayfasına dön
            if hasattr(self, '_welcome') and self._welcome:
                self.stack.setCurrentWidget(self._welcome)
                self.page_title.setText("")
                self.sidebar.set_active("")

        # Ekle formunu sıfırla (sonraki açılışta taze form)
        if "Personel Ekle" in self._pages:
            del self._pages["Personel Ekle"]

    def _on_cihaz_saved(self):
        """Cihaz kaydedildikten/iptal edildikten sonra listeye dön ve yenile."""
        # Cihaz Ekle sayfasını kaldır
        if "Cihaz Ekle" in self._pages:
            old = self._pages.pop("Cihaz Ekle")
            self.stack.removeWidget(old)
            old.deleteLater()

        # Cihaz Listesi sayfasına geç, yoksa welcome'a dön
        if "Cihaz Listesi" in self._pages:
            page = self._pages["Cihaz Listesi"]
            if hasattr(page, "load_data"):
                page.load_data()
            self.stack.setCurrentWidget(page)
            self.page_title.setText("Cihaz Listesi")
            self.sidebar.set_active("Cihaz Listesi")
        else:
            self.stack.setCurrentWidget(self._welcome)
            self.page_title.setVisible(False)
            self.sidebar.set_active("")

    def _open_cihaz_duzenle(self, data):
        """Cihaz düzenleme sayfasını aç."""
        # Eğer Cihaz Ekle sayfası zaten açıksa kapat (temiz başlasın)
        if "Cihaz Ekle" in self._pages:
            old = self._pages.pop("Cihaz Ekle")
            self.stack.removeWidget(old)
            old.deleteLater()
            
        from ui.pages.cihaz.cihaz_ekle import CihazEklePage
        page = CihazEklePage(
            db=self._db,
            on_saved=self._on_cihaz_saved
        )
        
        self._pages["Cihaz Ekle"] = page
        self.stack.addWidget(page)
        self.stack.setCurrentWidget(page)
        
        self.page_title.setText("Cihaz Ekle")
        self.page_title.setVisible(True)

    def _open_cihaz_merkez(self, data):
        """Cihaz 360° merkez sayfasını aç (v3)."""
        cihaz_id = data.get("Cihazid", "")
        merkez_key = f"__cihaz_merkez_{cihaz_id}"

        # Eğer zaten açıksa kapat ve yeniden oluştur
        if merkez_key in self._pages:
            old = self._pages.pop(merkez_key)
            self.stack.removeWidget(old)
            old.deleteLater()

        from ui.pages.cihaz.cihaz_merkez import CihazMerkezPage
        page = CihazMerkezPage(db=self._db, cihaz_id=cihaz_id, sabitler_cache=self._sabitler_cache)
        page.kapat_istegi.connect(lambda: self._back_to_cihaz_listesi(merkez_key))

        self._pages[merkez_key] = page
        self.stack.addWidget(page)
        self.stack.setCurrentWidget(page)

        marka = data.get("MarkaAdi", "")
        model = data.get("VersiyonModel", "")
        self.page_title.setText(f"Cihaz — {marka} {model}")
        self.page_title.setVisible(True)

    def _open_cihaz_detay(self, data):
        """Geriye dönük uyumluluk — merkeze yönlendir."""
        self._open_cihaz_merkez(data)

    def _back_to_cihaz_listesi(self, detay_key):
        """Detay sayfasından cihaz listesine geri dön."""
        # Detay sayfasını kapat
        if detay_key in self._pages:
            old = self._pages.pop(detay_key)
            self.stack.removeWidget(old)
            old.deleteLater()
            
        # Listeyi aç
        if "Cihaz Listesi" in self._pages:
            page = self._pages["Cihaz Listesi"]
            if hasattr(page, "load_data"):
                page.load_data()
            self.stack.setCurrentWidget(page)
            self.page_title.setText("Cihaz Listesi")
            self.sidebar.set_active("Cihaz Listesi")

    def open_periodic_maintenance_for_device(self, device_data):
        """Cihaz listesinden periyodik bakım sayfasına yönlendir."""
        # Teknik Hizmetler → Periyodik Bakım sekmesini aç
        self._on_menu_clicked("CİHAZ", "Teknik Hizmetler")
        page = self._pages.get("Teknik Hizmetler")
        if page and hasattr(page, "open_tab"):
            cihaz_id = device_data.get("Cihazid", "") if isinstance(device_data, dict) else ""
            if cihaz_id:
                page.open_tab("BAKIM", cihaz_id=cihaz_id)

    def _setup_theme_listener(self):
        """Tema değişikliğini dinle"""
        try:
            from ui.theme_manager import ThemeManager
            theme_manager = ThemeManager.instance()
            theme_manager.theme_changed.connect(self._on_theme_changed)
            logger.debug("MainWindow tema değişikliği listener'ı bağlandı")
        except Exception as e:
            logger.error(f"Tema değişikliği listener kurulumu hatası: {e}")

    @Slot(str)
    def _on_theme_changed(self, theme_name: str):
        """
        Tema değiştiğinde UI'ı günceller.

        Aşama 2 sonrası: Tüm renkler QSS property selector'larından geliyor.
        app.setStyleSheet() çağrısı (ThemeManager içinde) yeni QSS'i zaten uyguladı.
        Burada sadece Qt'nin style cache'ini temizlemek yeterli — sayfa yıkmaya gerek yok.
        """
        logger.info(f"Tema değiştirildi: {theme_name} — UI yenileniyor")
        try:
            # Tüm pencereyi yenile — alt widget'lar otomatik güncellenir
            self.update()
            logger.info(f"Tema '{theme_name}' uygulandı")
        except Exception as e:
            logger.error(f"Tema yenileme hatası: {e}", exc_info=True)
